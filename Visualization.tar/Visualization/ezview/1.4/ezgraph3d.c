/* ------------------------------------------------------------------------- */
/* ezgraph3d.c -- Graphics routines (except for marching cubes).
 *
 * Copyright (C) 1996 - 1998, 2006, 2007 Dwight Barkley and Matthew Dowle
 *
 * RCS Information
 * ---------------------------
 * $Revision: 1.5.1.1 $
 * $Date: 2007/05/07 10:07:03 $
 * ------------------------------------------------------------------------- */

/* Modifications for EZView: 2010-12, Vadim Biktashev vnb@liv.ac.uk             */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xutil.h> 
#include <X11/keysym.h>
#include <X11/keysymdef.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glx.h>

#include "ezscroll.h"
#include "ezgraph3d.h"
#include "ezmarching.h"

/* -------------------------------------------------------------------------
 * This file contains all graphics manipulation routines. The functions that
 * compute the iso-surfaces and filaments and render these are in ezmarching.
 *
 * The important things to know about this file are: 
 *
 * (1) X11 is used to open the graphics window and handle the events
 * (i.e. key presses and pointer motions within the window).  InitX() is a
 * long routine that opens the window; Event_check() contains the event loop
 * that looks for window events; QuitX() quits X obviously. You should be
 * able to switch over to a higher-level method with only minor
 * modifications except for these routines.
 *
 * (2) After the window is open, OpenGL is used to handle all the rendering.
 * myReshape() must be called before anything can be plotted.  To understand
 * this function see the OpenGL manual.
 *
 * The routines near the top of this file handle the interactive graphics
 * through OpenGL calls.  Note: to add a new interactive feature, add to the
 * event loop in Event_check() and add a corresponding routine to perform the
 * desired task.
 *
 * (3) Note on the graphics modes.
 *
 * There are 3 modes the program can be in: 
 *   MODE_SIMULATING  Simulation progresses through time (it cannot be 
 *                    rotated while in this mode)
 *   MODE_VIEWING     Simulation is paused.  While in this mode, graphics 
 *                    lists are created for use in rotations.  New list must
 *                    be created for each basic change in what is plotted,
 *                    e.g switching u-field to v-field, turning on clipping, 
 *                    etc.
 *   MODE_ROTATING    Mouse button 1 is down so the view responds to mouse 
 *                    motion.  Graphics lists are called and no new 
 *                    iso-surfaces are computed (i.e. fast rotations).
 * ------------------------------------------------------------------------- */

/* 
 * Global variables for this file only 
 * ----------------------------------- */
static Display      *theDisplay;
static int           theDWidth;
static int           theDHeight;

static Window        theWindow;
static XTextProperty theWindowName, theIconName;
static int 	     WindowWidth;
static int 	     WindowHeight;
static int           winx, winy;

static int horspace, vertspace;

/* static int         field;            /\* Field being viewed *\/  */
static int         ezmode, ezmode_save; /* Mode flag */
static int         lastx, lasty;     /* Used by Rotate() and Mouse_down() */
static GLbitfield  ezdepth;          /* Depth buffer flag */ 

/* These arrays set the light sources and properties. See Draw_ini(). */

static GLfloat mat_emission[]  = {0.5, 0.5, 0.5, 1.0};
static GLfloat mat_diffusive[] = {0, 0, 0, 0};
static GLfloat mat_specular[] = {1.0, 1.0, 1.0, 1.0};
static GLfloat mat_shininess[] = {100.0};

static GLfloat light_position0[] = {100, 100, -100, 0};

/* static GLfloat light_ambient1[] = {0., 0., 0., 0.}; */
/* static GLfloat light_diffuse1[] = {0.4, 0.4, 0.4, 0.0}; */
/* static GLfloat light_specular1[] = {0.3, 0.3, 0.3, 0.0}; */

/* static GLfloat light_position1[] = {-100, 100, -100, 0}; */
/* static GLfloat light_position2[] = {-100, -100, -100, 0}; */
/* static GLfloat light_position3[] = {100, -100, -100, 0}; */


/* 
 * Private functions 
 * ----------------- */
static void  Restart                  (void);
/* static void  Pause                    (void); */
static void  Make_lists               (void);
/* static void  View_u_field             (void); */
/* static void  View_v_field             (void); */
static void  Toggle_surface_drawing   (void);
static void  Toggle_backs_removal     (void);
static void  Toggle_clipping_plane    (void);
static void  Toggle_depth_buffer      (void);
static void  Toggle_filament_plotting (void);
static void  Toggle_history_writing   (void);
static void  Toggle_image_writing      (void);
static int   Toggle_filament_writing  (void);
static void  Mouse_up                 (void);
static void  Mouse_down               (int x, int y);
/* Extension to Dowle-Barkley control */
static void  Rotate                   (int x, int y, 
				       float new_theta, float new_phi);
static void  Tilt                     (float new_psi);
/* "Iris Explorer" style control */
static void  Pitch		      (float angle);
static void  Yaw                      (float angle);
static void  Roll		      (float angle);
static void  Turn                     (int x, int y);
/* pseudo-Euler coords (turn to true Euler when find out what it is!) */
static void  setView                  (GLfloat new_theta, GLfloat new_phi,
				       GLfloat new_psi, GLfloat new_distance);
static void  getView                  (GLfloat *current_theta, GLfloat *current_phi, GLfloat *current_psi);

static void  Draw_view                (void);
static void  myReshape                (int w, int h);
static void  Assign_par               (void);
static void  InitX                    (int *winx, int *winy, 
				       int width, int height);
static Bool  WaitForNotify            (Display *d, XEvent *e, char *arg);
static void  Save_image               (void);

static void  Save_all                 (void);
static void  MoveWindow               (int dx, int dy);

/* Notify the user when the program is busy drawing */
static void  before_drawing (void);
static void  after_drawing (void);

/* ========================================================================= */

void Draw (void) {
  /* Highest level plotting routine. If in MODE_SIMULATING or
   * MODE_VIEWING then call the Marching_Cubes function.
   *
   * If in MODE_ROTATING call glCallList() which rapidly plots the new view
   * of the pre-compiled graphics scene. */

  Draw_title();
  before_drawing();

  {
    Real Lx=imax-imin+1;
    Real Ly=jmax-jmin+1;
    Real Lz=kmax-kmin+1;
    Real Lmax=max(max(Lx,Ly),Lz);
    plot_length[0] = Lx/Lmax;
    plot_length[1] = Ly/Lmax;
    plot_length[2] = Lz/Lmax;
    plot_ini[0] = (imin-1)/Lmax;
    plot_ini[1] = (jmin-1)/Lmax;
    plot_ini[2] = (kmin-1)/Lmax;
  }

  glClearColor(bg_r,bg_g,bg_b,0.0); 

  glClear(GL_COLOR_BUFFER_BIT | ezdepth);  /* Clear the color buffer.  
					    * Clear the depth buffer if on, 
					    * (ezdepth=DEPTH_BUFFER_BIT) */
  switch (ezmode) {
  case MODE_SIMULATING :
  case MODE_VIEWING :
    if (norm_res==rot_res) {
      glNewList(ISO_LIST, GL_COMPILE);
      Marching_cubes(norm_res);
      glEndList();
      glCallList(ISO_LIST);
    } else {
      Marching_cubes(norm_res);
    }
    break;
  case MODE_ROTATING :
    glCallList(ISO_LIST);
    break;
  }

  if (GRAPHICS) 
    glXSwapBuffers(theDisplay,theWindow); 

  after_drawing();

  /* If not in simulating mode, save images using 'I' key */
  if (write_images && ezmode==MODE_SIMULATING)
    Save_image();
}
/* ========================================================================= */

/* Redraw the existing list from a different view */
void Draw_view (void) {
  ezmode_save=ezmode;
  ezmode=MODE_ROTATING;
  Draw();
  ezmode=ezmode_save;
}
/* ========================================================================= */

/* (Re)write the window title with flags and values */
static char name[256]=WINDOW_TITLE; 
static char *pname=&(name[0]);
static char *busychar;
void Draw_title (void) {
   /* static char  *name = WINDOW_TITLE; */
   char surfacelayers[16];
   char filamentlayers[16];
   sprintf(surfacelayers,"%d|%d",ulayer,vlayer);
   sprintf(filamentlayers,"%d:%d",layer1,layer2);
   /* strcpy(name,WINDOW_TITLE); */
   /* sprintf(name,"%s",WINDOW_TITLE); */
   sprintf(name,"%s %s%c m=%d %s [%c%c%c] %s /%c%c%c/ (%.1f,%.1f,%.1f,%.2f)",
	   WINDOW_TITLE,
	   (mstep>0)?"->":"<-",
	   ezmode==MODE_SIMULATING?' ':'*',
	   m,

	   show_surface?   surfacelayers:"(N)",
	   remove_backs?  'B':'_',
	   clipping?      'C':'_',
	   ezdepth?       'D':'_',

	   show_filament?filamentlayers:"(F)",

	   write_history? 'H':'_',
	   write_images?  'I':'_',
	   write_filament?'W':'_',
	   theta, phi, psi, distance
	   );
   XStringListToTextProperty(&pname,1,&theWindowName);
   XSetWMName(theDisplay, theWindow, &theWindowName);
   busychar=pname+strlen(WINDOW_TITLE)+1+2;
}
/* ========================================================================= */

static void Make_lists (void)
{
  /* Make new graphics lists for fast rotations. */
  if (norm_res==rot_res) return;
  glNewList(ISO_LIST, GL_COMPILE);
  before_drawing();
  Marching_cubes(rot_res);
  after_drawing();
  glEndList();
}
/* ========================================================================= */

static void Restart (void)
{
  /* Return to MODE_SIMULATING. This has the effect of restarting the
     simulation via a return from Event_check(). */

  if (ezmode == MODE_VIEWING) {
    ezmode = MODE_SIMULATING;
  }
}
/* ========================================================================= */

/* static */ void Pause (void)
{
  /* The simulation has paused -- go to MODE_VIEWING.  Call Make_lists() in
   * preparation for rotation. */

  if (ezmode == MODE_SIMULATING) {
    ezmode = MODE_VIEWING;
    Make_lists();
  }
}
/* ========================================================================= */

/* static void View_u_field (void) */
/* { */
/*   field = U_FIELD; */
/*   if (ezmode != MODE_SIMULATING) { */
/*     Make_lists(); */
/*     Draw(); */
/*   } */
/* } */
/* ========================================================================= */

/* static void View_v_field (void) */
/* { */
/*   field = V_FIELD; */
/*   if (ezmode != MODE_SIMULATING) { */
/*     Make_lists(); */
/*     Draw(); */
/*   } */
/* } */
/* ========================================================================= */

static void Toggle_surface_drawing (void) {
  if (show_surface) show_surface = FALSE;
  else show_surface = TRUE;

  if (ezmode != MODE_SIMULATING) {
    Make_lists();
    Draw();
  }
}
/* ========================================================================= */
  

static void Toggle_backs_removal (void)
{
  if (remove_backs) remove_backs = FALSE;
  else remove_backs = TRUE;

  if (ezmode != MODE_SIMULATING) {
    Make_lists();
    Draw();
  }
}
/* ========================================================================= */

static void Toggle_clipping_plane (void)
{
  if (clipping) {
    glDisable(GL_CLIP_PLANE0);
    clipping = FALSE;
  }
  else {
    glEnable(GL_CLIP_PLANE0);
    clipping = TRUE;
  }
  if (ezmode != MODE_SIMULATING) {
    Make_lists(); 
    Draw();
  }
}
/* ========================================================================= */

static void Toggle_depth_buffer (void)
{
  if (glIsEnabled(GL_DEPTH_TEST)) {
    glDisable(GL_DEPTH_TEST);
    ezdepth = 0; 
  }
  else {
    glEnable(GL_DEPTH_TEST);
    ezdepth = GL_DEPTH_BUFFER_BIT;
  }
  if (ezmode != MODE_SIMULATING) {
    Draw();
  }
}
/* ========================================================================= */

static void Toggle_filament_plotting (void)
{
  if (show_filament) show_filament = FALSE;
  else show_filament = TRUE;

  if (ezmode != MODE_SIMULATING) {
    Make_lists();
    Draw();
  }
}
/* ========================================================================= */

static void Toggle_history_writing (void)
{
  if (write_history) write_history = FALSE;
  else {
    if (verbose>2) printf("will write to history file now\n");
    write_history = TRUE;
  }
  if (ezmode != MODE_SIMULATING) Draw_title();
}
/* ========================================================================= */

static void Toggle_image_writing (void)
{
  if (write_images) write_images = FALSE;
  else {
    write_images = TRUE;
    if (verbose>2) printf("will save every image now\n");
  }
  if (ezmode != MODE_SIMULATING) Draw_title();
}
/* ========================================================================= */

static int Toggle_filament_writing (void)
{
  if (write_filament) write_filament = FALSE;
  else {
    write_filament = TRUE;
    if (verbose>2) printf("will write filament data now\n");
  }
  if (ezmode != MODE_SIMULATING) Draw_title();
  return write_filament;
}
/* ========================================================================= */

static void Mouse_up (void)
{
  if (ezmode == MODE_ROTATING) {
    ezmode = MODE_VIEWING;
    if (rot_res!=norm_res) Draw();
  }
}
/* ========================================================================= */

static GLfloat mouse_down_mx[16];
static void Mouse_down (int x, int y) {
  /* If the mode is MODE_VIEWING then on mouse down the state goes to
   * MODE_ROTATING.  x and y are the location of the mouse when the button
   * was pressed and these are saved as lastx and lasty for use in
   * rotating(). */

  if (ezmode != MODE_VIEWING) return;

  glMatrixMode(GL_MODELVIEW);
  glGetFloatv(GL_MODELVIEW_MATRIX, mouse_down_mx);

  lastx = x;    /* Rotate() uses these values to calculate the distance  */ 
  lasty = y;    /* moved by the mouse since the last Draw() call */

  ezmode = MODE_ROTATING;
  if (rot_res!=norm_res) Draw();
  if (verbose>=4) printf("Mouse down at (%d,%d) within (%d,%d)\n",lastx,lasty,WindowWidth,WindowHeight);

}
/* ========================================================================= */

static void Rotate (int x, int y, float new_theta, float new_phi) {
  /* Rotates volume either in response to changes in mouse location or to
   * angles new_theta, new_phi.  More specifically:
   *
   * if MODE_ROTATING: change the viewing angles theta and phi by the
   *   difference of (x,y) - (lastx,lasty), i.e. the difference between the
   *   current mouse location and the previous location (set in call to
   *   Rotate() or to Mouse_down()).  
   *
   * else (not in MODE_ROTATING): set theta and phi to incoming values. */

  /* static GLfloat theta, phi; */ 

  if (ezmode == MODE_ROTATING) {
    theta += ROTATE_SCALE * (x-lastx);
    phi   -= ROTATE_SCALE * (y-lasty);
    lastx = x;
    lasty = y;
  }
  else {
    theta = new_theta;
    phi   = new_phi;
  }

  /* Require both theta and phi to be in the interval [-180,180).  Extending
   * the range of theta to [-180,180) prevents 'flipping' at theta equal 90
   * and -90. */

  while (theta > 180.0) theta -= 360.0;
  while (theta <= -180) theta += 360.0;
  while (phi > 180.0) phi -= 360.0;
  while (phi <= -180) phi += 360.0;

  setView((GLfloat)theta, (GLfloat)phi, (GLfloat)psi, (GLfloat)distance);
}
/* ========================================================================= */


/* Turns the volume round y axis prior to rotating by theta and phi. */
static void Tilt (float new_psi)   {
  psi   = new_psi;

  /* Require psi to be in the interval [-180,180). */

  while (psi >   180.0) psi-=360.0;
  while (psi <= -180.0) psi+=360.0;

  setView((GLfloat)theta, (GLfloat)phi, (GLfloat)psi, (GLfloat)distance);
}
/* ========================================================================= */

static void Pitch (float angle) {
  static GLfloat m[16];
  GLfloat current_theta, current_phi, current_psi;
  glMatrixMode(GL_MODELVIEW);
  glGetFloatv(GL_MODELVIEW_MATRIX, m);

  glLoadIdentity();
  glTranslatef(0.0,0.0,-distance); 
  glRotatef(-angle,1,0,0);
  glTranslatef(0.0,0.0,+distance);

  glMultMatrixf(m);

  /* indirect, in case of types conflict */
  getView(&current_theta, &current_phi, &current_psi);
  theta=current_theta; phi=current_phi; psi=current_psi;
}
/* ========================================================================= */

static void Yaw (float angle) {
  static GLfloat m[16];
  GLfloat current_theta, current_phi, current_psi;
  glMatrixMode(GL_MODELVIEW);
  glGetFloatv(GL_MODELVIEW_MATRIX, m);

  glLoadIdentity();
  glTranslatef(0.0,0.0,-distance); 
  glRotatef(angle,0,1,0);
  glTranslatef(0.0,0.0,+distance); 

  glMultMatrixf(m);

  getView(&current_theta, &current_phi, &current_psi);
  theta=current_theta; phi=current_phi; psi=current_psi;
}
/* ========================================================================= */

static void Roll (float angle) {
  static GLfloat m[16];
  GLfloat current_theta, current_phi, current_psi;
  glMatrixMode(GL_MODELVIEW);
  glGetFloatv(GL_MODELVIEW_MATRIX, m);

  glLoadIdentity();
  glTranslatef(0.0,0.0,-distance); 
  glRotatef(-angle,0,0,1);
  glTranslatef(0.0,0.0,+distance); 

  glMultMatrixf(m);

  getView(&current_theta, &current_phi, &current_psi);
  theta=current_theta; phi=current_phi; psi=current_psi;
}
/* ========================================================================= */

static void Turn (int x, int y) {
  /* In MODE_ROTATING, turn the box round in response to changes in mouse location.
   *
   * The model: the inscribed disk of radius r
   * is considered as 2D projection of a sphere,
   * that represents the SO3 coords that define the rotation, 
   * corresp. to new vs old mouse position. 
   */
  GLfloat new_theta, new_phi, new_psi;
  /* Radius and centre of the disk */
  float r=0.5*WINSIZE, xc=0.5*WINSIZE, yc=0.5*WINSIZE;
  float X0, Y0, Z0, P0, X1, Y1, Z1, P1, Xa, Ya, Za, crossnorm, dotprod, angle;

  if (ezmode != MODE_ROTATING) return; 

  if (verbose>=4) printf("(%d,%d) -> (%d,%d)\n",lastx,lasty,x,y);

  if (verbose>=4) printf("xc=%g yc=%g r=%g\n",xc,yc,r);

  /* Old mouse position on the "sphere", normalized and cropped */
  /* NB mouse position is in "raster coord" which is upside down so Y needs to be negated */
  X0=(lastx-xc)/r; Y0=-(lasty-yc)/r;
  P0=X0*X0+Y0*Y0;
  if (verbose>=4) printf("Old: x=%d X0=%g y=%d Y0=%g P0=%g\n",lastx,X0,lasty,Y0,P0);
  if (P0>1.0) {
    X0/=sqrt(P0);
    Y0/=sqrt(P0);
    P0=1.0;
  }
  Z0=sqrt(1.0-P0);

  /* New position */
  /* NB mouse position is in "raster coord" which is upside down so Y needs to be negated */
  X1=(x-xc)/r; Y1=-(y-yc)/r;
  P1=X1*X1+Y1*Y1;
  if (verbose>=4) printf("New: x=%d X1=%g y=%d Y1=%g P1=%g\n",x,X1,y,Y1,P1);
  if (P1>1.0) {
    X1/=sqrt(P1);
    Y1/=sqrt(P1);
    P1=1.0;
  }
  Z1=sqrt(1.0-P1);

  /* Cross-product */
  Xa=Y0*Z1-Y1*Z0;
  Ya=Z0*X1-Z1*X0;
  Za=X0*Y1-X1*Y0;

  /* Dot-product */
  dotprod=X0*X1+Y0*Y1+Z0*Z1;

  if (verbose>=4) printf("(%g,%g,%g) x (%g,%g,%g) = (%g,%g,%g) . (%g)",X0,Y0,Z0,X1,Y1,Z1,Xa,Ya,Za,dotprod);

  /* Its length is sin of rotation angle */
  crossnorm=sqrt(Xa*Xa+Ya*Ya+Za*Za);
  angle=asin(crossnorm)/deg;
  if (dotprod<0) angle=180.0-angle;
  /* Normalized vector as rotation axis */
  Xa/=crossnorm;
  Ya/=crossnorm;
  Za/=crossnorm;

  if (verbose>=4) printf("-> %g about (%g,%g,%g)\n",angle,Xa,Ya,Za);

  /* Now we do the rotation by prepending appropriate trans mx */
  /* to the one recorded at mouse-down time */
  glLoadIdentity();
  glTranslatef(0.0,0.0,-distance); 
  glRotatef(angle,Xa,Ya,Za);
  glTranslatef(0.0,0.0,+distance); 
  glMultMatrixf(mouse_down_mx);

  /* The resulting SO3 coords */
  getView(&new_theta, &new_phi, &new_psi);
  theta=new_theta; phi=new_phi; psi=new_psi;
}
/* ========================================================================= */


static void setView(GLfloat new_theta, GLfloat new_phi, 
		    GLfloat new_psi, GLfloat new_distance) {
  /* DB: OpenGL calls to set rendering (transformation matrix). Note that the
   * last call (which is the first action applied to a triangle being
   * rendered) is to center the 3D volume about the origin. There are then
   * rotations in (VNB: psi,) theta and phi.  The second translation pulls the view away
   * from the cube.  I have found that distance=5 is about right -- the
   * distance (as measured in unit lengths as they appear on the screen) the
   * volume is from the eye under normal view conditions is about 5.  In
   * principle this varies with the size of the window on the screen.  For
   * an orthographic projection this is irrelevant so long as the cube is in
   * the viewed volume. */

  theta=new_theta; phi=new_phi; psi=new_psi; distance=new_distance;

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(0.0,0.0,-new_distance); 
  glRotatef(-phi,1.0,0.0,0.0);
  glRotatef(theta,0.0,0.0,1.0);
  glRotatef(psi,0.0,1.0,0.0);
  /* glTranslatef(-plot_length[0]/2,-plot_length[1]/2,-plot_length[2]/2); */
  glTranslatef(
    -(plot_ini[0]+plot_length[0]/2),
    -(plot_ini[1]+plot_length[1]/2),
    -(plot_ini[2]+plot_length[2]/2)
  );							/* glFlush(); sleep(1); */

  /* This was used for debugging; perhaps can be thrown away at some stage */
  /* if (verbose>=4) { */
  /*   GLfloat m[16]; */
  /*   /\* int i,j; *\/ */
  /*   /\* http://en.wikipedia.org/wiki/Rotation_matrix *\/ */
  /*   double eulertheta=theta*deg; */
  /*   double eulerphi=-phi*deg; */
  /*   double eulerpsi=psi*deg; */
  /*   double costh=cos(eulertheta), sinth=sin(eulertheta); */
  /*   double cosph=cos(eulerphi),   sinph=sin(eulerphi); */
  /*   double cosps=cos(eulerpsi),   sinps=sin(eulerpsi); */
  /*   GLfloat new_theta, new_phi, new_psi; */
  /*   printf("????????????????????\n"); */
  /*   printf("%lf\t%lf\t%lf\n", costh*cosps, -cosph*sinps+sinph*sinth*cosps,  sinph*sinps+cosph*sinth*cosps); */
  /*   printf("%lf\t%lf\t%lf\n", costh*sinps,  cosph*cosps+sinph*sinth*sinps, -sinph*cosps+cosph*sinth*sinps); */
  /*   printf("%lf\t%lf\t%lf\n",-sinth      ,              sinph*costh      ,        cosph*costh            ); */
  /*   printf("!!!!!!!!!!!!!!!!!!!!\n"); */
  /*   glGetFloatv(GL_MODELVIEW_MATRIX, m); */
  /*   #define R(i,j) (double)(m[(j)-1+((i)-1)*4]) */
  /*   printf("%lf\t%lf\t%lf\n", R(1,1), R(1,3), R(1,2)); */
  /*   printf("%lf\t%lf\t%lf\n", R(3,1), R(3,3), R(3,2)); */
  /*   printf("%lf\t%lf\t%lf\n", R(2,1), R(2,3), R(2,2)); */
  /*   printf("========  %d =======\n",(int)(sizeof(GLfloat))); */
  /*   printf("\n"); */
  /*   getView(&new_theta,&new_phi,&new_psi); */
  /*   printf("(theta,phi,psi): %f,%f,%f -> %f,%f,%f\n",theta,phi,psi,(float)new_theta,(float)new_phi,(float)new_psi); */
  /* } */
}
/* ========================================================================= */

/* Reconstruct the current SO3 coord from the current transformation matrix */
/* Arbitrarily restric theta to [-pi/2,pi/2] range */
static void getView(GLfloat *current_theta, GLfloat *current_phi, GLfloat *current_psi) {
  GLfloat m[16];
  double eulertheta, costh;
  double eulerphi;
  double eulerpsi;
  double R11, R12, R13, R21, R22, R23, R31, R32, R33;
  glGetFloatv(GL_MODELVIEW_MATRIX, m);
  #define r(i,j) (double)(m[(j)-1+((i)-1)*4])
  R11=r(1,1); R12=r(1,3); R13=r(1,2);
  R21=r(3,1); R22=r(3,3); R23=r(3,2);
  R31=r(2,1); R32=r(2,3); R33=r(2,2);
  /* http://gregslabaugh.name/publications/euler.pdf with psi<->phi */
  if (R31==1.0) {
    /* sinth=-1 costh=0 */
    /* (0          , -cosph*sinps-sinph*cosps,  sinph*sinps-cosph*cosps); */
    /* (0          ,  cosph*cosps-sinph*sinps, -sinph*cosps-cosph*sinps); */
    /* (1          ,               0         ,        0                ); */
    /**/
    /* (0          , -sin(phi+psi),  -cos(phi+psi) */
    /* (0          ,  cos(phi+psi),  -sin(phi+psi); */
    /* (1          ,  0         ,        0       ); */
    eulerpsi=0.0;
    eulerphi=atan2(-R12,-R13);
  } else if (R31==-1.0) {
    /* sinth=1 costh=0 */
    /* (0       , -cosph*sinps+sinph*cosps,  sinph*sinps+cosph*cosps); */
    /* (0       ,  cosph*cosps+sinph*sinps, -sinph*cosps+cosph*sinps); */
    /* (-1      ,              0          ,        0                ); */
    /**/
    /* (0       ,  sin(phi-psi),  cos(phi-psi); */
    /* (0       ,  cos(phi-psi),  sin(psi-phi); */
    /* (-1      ,       0      ,      0      ); */
    eulerpsi=0.0;
    eulerphi=atan2(R12,R13);
  } else {
    /* (costh*cosps, -cosph*sinps+sinph*sinth*cosps,  sinph*sinps+cosph*sinth*cosps); */
    /* (costh*sinps,  cosph*cosps+sinph*sinth*sinps, -sinph*cosps+cosph*sinth*sinps); */
    /* (-sinth     ,              sinph*costh      ,        cosph*costh            ); */
    eulertheta=-asin(R31);
    costh=cos(eulertheta);
    eulerphi=atan2(R32/costh,R33/costh);
    eulerpsi=atan2(R21/costh,R11/costh);
  }
  *current_theta=eulertheta/deg;
  *current_phi=-eulerphi/deg;
  *current_psi=eulerpsi/deg;
}
/* ========================================================================= */


static void myReshape(int w, int h)
{
  GLfloat half_width;

  /* half_width is the half width of the volume viewed in GL.  In general if
   * half_width is large, then rendered simulation volume will appear small,
   * and vice versa.  PLOT_SIZE in ezgraph3d.h allows adjustment of this
   * without changing any of the code below.
   *
   * For orthographic projection setting half_width this is straightforward:
   * The simulation volume has maximum side of 1 in graphics coordinates
   * (set Draw_ini()).  If half_width is set to sqrt(3)/2 = 0.866..., then a
   * unit cube, and hence the simulation volume, will always lie entirely
   * within the viewport so I choose this for the default.  For ortho
   * projection, the near are far values are set to large values and are
   * irrelevant so long as the volume lies between near and far.
   * 
   * For perspective projection the situation is more complicated because
   * the half_width applies at the value of near (see the OpenGL manual).
   * Hence the value of near and half_width must be set together so that a
   * unit cube fills the viewport but does not cut the near plane.  The
   * values below accomplish this.  The far value if irrelevant and is set to
   * a large value. */

  glMatrixMode (GL_PROJECTION);
  glLoadIdentity ();
#if PERSPECTIVE   
  /* Perspective projection */
  half_width = 0.7/PLOT_SIZE;
  glFrustum(-half_width, half_width, -half_width, half_width, 
	    distance-1., 20.);
#else            
  /* Orthographic projection */
  half_width = 0.866/PLOT_SIZE;
  glOrtho (-half_width, half_width, -half_width, half_width, -20., 20.); 
#endif
  glMatrixMode (GL_MODELVIEW);
  glViewport (0, 0, w, h);

  WindowWidth=w; WindowHeight=h;
}
/* ========================================================================= */

void Draw_ini (void) {
  /* Initialize everything necessary for 3D plotting.  */
  int show_filament_save=show_filament;

  show_filament = FALSE;

  /* The lengths of the simulation volume in graphics coordinates are set.  I
   * choose to have the largest plot_length=1.  Thus the volume lies inside
   * the unit cube in graphics coordinates. */
  /* VNB: this is initial setup, to allow the clipping plane; redone every Draw */
  {
    Real Lx=imax-imin+1;
    Real Ly=jmax-jmin+1;
    Real Lz=kmax-kmin+1;
    Real Lmax=max(max(Lx,Ly),Lz);
    plot_length[0] = Lx/Lmax;
    plot_length[1] = Ly/Lmax;
    plot_length[2] = Lz/Lmax;
    plot_ini[0] = (imin-1)/Lmax;
    plot_ini[1] = (jmin-1)/Lmax;
    plot_ini[2] = (kmin-1)/Lmax;
  }

  /* Initialization for marching cubes. */
  Marching_ini();

  /* At this point everything has been initialized for finding filaments
   * without graphics.  Can return after setting a few things.  Setting field
   * to NO_FIELD and ezmode to MODE_SIMULATING will give only minimum OpenGL
   * calls.  clipping must be set but is not important. */

  if( !GRAPHICS ) {
    show_surface = FALSE;
    ezmode = MODE_SIMULATING;   
    clipping = FALSE;
    return;
  }

  /* Create X window and prepares for use by OpenGL */
  winx=WINX; winy=WINY;
  InitX(&winx,&winy,WINSIZE,WINSIZE);

  /* The default should be smooth anyway */
  glShadeModel(GL_SMOOTH); 

  /* The depth buffer is disabled by default in GL.  Here we enable
   * it. To start with depth buffer disabled, don't call glEnable and
   * set ezdepth = 0. */
  glEnable(GL_DEPTH_TEST);
  ezdepth = GL_DEPTH_BUFFER_BIT;

  /* try - VNB */
  /* glEnable(GL_NORMALIZE); */

  /* Enable light sources and properties */
  glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION,  mat_emission);
  glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,   mat_diffusive);
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR,  mat_specular);
  glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);

  light_position0[0]=lightx;
  light_position0[1]=lighty;
  light_position0[2]=lightz;
  light_position0[3]=lightw;
  glLightfv(GL_LIGHT0, GL_POSITION, light_position0);

/*   glLightfv(GL_LIGHT1, GL_AMBIENT,  light_ambient1); */
/*   glLightfv(GL_LIGHT1, GL_DIFFUSE,  light_diffuse1); */
/*   glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular1); */

  /* glLightfv(GL_LIGHT1, GL_POSITION, light_position1); */

  /* glLightfv(GL_LIGHT2, GL_POSITION, light_position2); */
  /* glLightfv(GL_LIGHT3, GL_POSITION, light_position3); */

  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);

  /* glEnable(GL_LIGHT1); */
/*   glEnable(GL_LIGHT2); */
/*   glEnable(GL_LIGHT3); */
  glEnable(GL_COLOR_MATERIAL); 
  glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
  /* glColorMaterial(GL_FRONT_AND_BACK,GL_DIFFUSE); */ 

  glEnable(GL_BLEND);
  glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
/*   glBlendFunc (GL_SRC_ALPHA, GL_ONE); */

  /* Set the background color.  */
  glClearColor(bg_r,bg_g,bg_b,0.0); 

  /* Set up the clipping plane.  Note that clipping is not on enabled
   * initially, but could be by inserting a call to Toggle_clipping_plane().
   * Here the clipping plane is set to pass half way through the volume.
   * plane[3] controls this.  I start with clipping off (clipping=FALSE) */
  {
    GLdouble plane[4]; 
    plane[0] = 0.0; 
    plane[1] = 0.0;
    plane[2] = -1.0;
    plane[3] = plot_length[2]/2;
    setView(0., 0., 0., distance0);
    glClipPlane(GL_CLIP_PLANE0, plane);
    /* clipping = FALSE; - this is set in the task file now */
  }

  /* Initialize the view direction */
  /* Rotate(0, 0, (float)INITIAL_THETA, (float)INITIAL_PHI); */   
  /* Rotate(0, 0, theta, phi); */
  setView(theta0,phi0,psi0,distance0);

  /* Set starting mode */
  if(START_PAUSED) {
    ezmode = MODE_VIEWING; 
    Make_lists();
  }
  else {
    ezmode = MODE_SIMULATING;   
  }
  show_filament=show_filament_save;
}
/* ========================================================================= */

/* Interactively reassign any of the parameters listed in ezpar.h, */
/* in the parent command shell */
enum par_t {
  par_int,
  par_Real
};
enum par_count {
#define _(n,t,i) par_##n,
  #include "ezpar.h"
  numpar
#undef _(n,t,i)
};
typedef struct {char *name; void *addr;enum par_t type;} pardef;
pardef pars[] = {
#define _(n,t,i) {#n,(void *)&n,par_##t},
  #include "ezpar.h"
  {"",NULL,par_int}
#undef _(n,t,i)
};
static void  Assign_par (void) {
  #define SEP " \t\r\b\n="
  #define BUFLEN 4096
  char buf[BUFLEN], *name, *value, *lasts;
  int ip, np;
  #define _(n,t,i) t n##prev;
  #include "ezpar.h"
  #undef _(n,t,i)

  while (1) {
    #define _(n,t,i) n##prev=n;
    #include "ezpar.h"
    #undef _(n,t,i)
    printf("parameter=");
    fgets(buf,BUFLEN,stdin);
    name=strtok_r(buf,SEP,&lasts);
    if (!name) break;
    np=-1;
    for(ip=0;ip<numpar;ip++) if(strcasecmp(buf,pars[ip].name)==0) np=ip;
    if (np==-1) {
      printf("Known parameters:");
      for (ip=0;ip<numpar;ip++) printf("%s%c",pars[ip].name,ip<numpar-1?',':'\n');
      continue;
    }
    switch (pars[np].type) {
    case par_int:
      printf("old value=%d new value=",*(int *)pars[np].addr);
      fgets(buf,BUFLEN,stdin);
      value=strtok_r(buf,SEP,&lasts);
      if (!value) continue;
      sscanf(value,"%d",(int *)pars[np].addr);
      printf("%s=%d\n",pars[np].name,*(int *)(pars[np].addr));
      break;
    case par_Real:
      printf("old value="FFMT" new value=",*(Real *)pars[np].addr);
      fgets(buf,BUFLEN,stdin);
      value=strtok_r(buf,SEP,&lasts);
      if (!value) continue;
      sscanf(value,FFMT,(Real *)(pars[np].addr));
      printf("%s="FFMT"\n",pars[np].name,*(Real *)(pars[np].addr));
      break;
    }
    #define chd(n) ((n)!=(n##prev))
    if (chd(m)||chd(ulayer)||chd(vlayer)) {
      if (verbose>=3) printf("need to re-read due to a changed parameter\n");
      Read_fmt(fmt,template,m);
    }
    if (chd(theta) || chd(phi) || chd(psi) || chd(distance)) {
      if (verbose>=3) printf("need to setView due to a changed parameter\n");
      setView(theta,phi,psi,distance);  /* some parameters affect camera position */
    }

    /* Light position changed: more than redraw */
    if (chd(lightx)||chd(lighty)||chd(lightz)||chd(lightw)) {
      light_position0[0]=lightx;
      light_position0[1]=lighty;
      light_position0[2]=lightz;
      light_position0[3]=lightw;
      glLightfv(GL_LIGHT0, GL_POSITION, light_position0);
    }

    /* From the opposite: the few pars that don't require redraw */
    if (!chd(mmin)&&!chd(mmax)&&!chd(mstep)&&!chd(write_filament)&&
	!chd(write_images)&&!chd(write_history)&&!chd(hist_x)&&!chd(hist_y)&&!chd(hist_z)&&
	!chd(grid_h)&&!chd(dt)
	) {
      if (verbose>=3) printf("need to re-draw due to a changed parameter\n");
      Make_lists(); 
      Draw();                   /* nearly all affect the picture */
    }

    if (m>mmax) mmax=m;	      /* automatically extend m range if needed */
    if (m<mmin) mmin=m;
    #undef chd
  }
  XRaiseWindow(theDisplay,theWindow);
  XSetInputFocus(theDisplay, theWindow, RevertToParent, CurrentTime); 
}
/* ========================================================================= */

void Save_all (void) {
  int write_filament_save=write_filament;
  write_filament = TRUE;
  Write_history(m);
  Draw();
  Save_image();
  write_filament = write_filament_save;
}
/* ========================================================================= */

void MoveWindow (int dx, int dy) {
  winx += dx;
  if (horspace) {
    while (winx<0) winx+=horspace;
    while (winx>=horspace) winx-=horspace;
  }
  winy += dy;
  if (vertspace) {
    while (winy<0) winy+=vertspace;	
    while (winy>=vertspace) winy-=vertspace;
  }
  XMoveWindow(theDisplay,theWindow,winx,winy); 
}
/* ========================================================================= */

int Event_check (void) {
  static XEvent         theEvent;
  static KeySym         theKeySym;
  static int            theKeyBufferMaxLen = 64;
  static char           theKeyBuffer[65];
  static XComposeStatus theComposeStatus;
  /* NB these masks discovered experimentally; */
  /* need to find out proper XLib coding for them if any */
  #define CTRL (0x0004)
  #define SHIFT (0x0001)
  static unsigned int   state;
  int                   write_filament_save;

  if( !GRAPHICS ) return(0);

  /* Save write_filament, and then turn filament writing is turned off.  This
   * is done so that no filaments are written as a result of graphics calls
   * in the event loop.  At the end, the write_filament is restored. */

  write_filament_save = write_filament;
  write_filament = FALSE;

  /* X Event Loop
   *
   * If there is something in the queue then each event is processed in
   * turn. When the queue is empty, and the mode (which may have been changed
   * by the events just processed) is MODE_SIMULATING then control is
   * returned (presumably to the main loop in main()).  However, when the
   * queue is empty and the mode is either MODE_ROTATING or MODE_VIEWING then
   * XNextEvent is called which blocks until the next X event is received
   * (eg. the space bar being pressed which sets the mode back to
   * MODE_SIMULATING and so control returns to main()). */

  while(XPending(theDisplay) || (ezmode != MODE_SIMULATING)) {

    XNextEvent(theDisplay, &theEvent);
    
    switch(theEvent.type) {      /* switch according to X event */
      
    case KeyPress:               /* A KeyPress event has occurred. */
      
      XLookupString((XKeyEvent *) &theEvent, theKeyBuffer,
		    theKeyBufferMaxLen, &theKeySym, &theComposeStatus);
      state= (theEvent.xkey.state) & ( CTRL | SHIFT );

      switch(theKeySym) {        /* switch according to the pressed key */

      case XK_Escape: exit(0);   /* hard exit, nothing saved */
      case XK_Q: case XK_q: return(1);
      case XK_P: case XK_p: Pause(); Draw(); break;
      case XK_space:  Restart(); break;

	/*******************************/
	
      case XK_B: case XK_b: Toggle_backs_removal(); break;
      case XK_C: case XK_c: Toggle_clipping_plane(); break;
      case XK_D: case XK_d: Toggle_depth_buffer(); break;
      case XK_F: case XK_f: Toggle_filament_plotting(); break;

      case XK_H: case XK_h: Toggle_history_writing(); break;
      case XK_I: case XK_i: Toggle_image_writing(); break;
      case XK_L: case XK_l: write_filament_save=Toggle_filament_writing(); break;
	
      case XK_N: case XK_n: Toggle_surface_drawing(); break;
      /* case XK_U: case XK_u: View_u_field(); break; */
      /* case XK_V: case XK_v: View_v_field(); break; */

      case XK_R: case XK_r: setView(theta0,phi0,psi0,distance0); Draw_view(); break; 
      case XK_S: case XK_s: Save_all(); break;
      case XK_Z: case XK_z: Rotate(0,0,0.,0.); Tilt(0.0); Draw_view(); break;

      case XK_0: color_mode=0; Make_lists(); Draw(); break;
      case XK_1: color_mode=1; Make_lists(); Draw(); break;
      case XK_2: color_mode=2; Make_lists(); Draw(); break;
      case XK_3: color_mode=3; Make_lists(); Draw(); break;
      case XK_4: color_mode=4; Make_lists(); Draw(); break;
      case XK_5: color_mode=5; Make_lists(); Draw(); break;
      case XK_6: color_mode=6; Make_lists(); Draw(); break;
      case XK_7: color_mode=7; Make_lists(); Draw(); break;
      case XK_8: color_mode=8; Make_lists(); Draw(); break;
      case XK_9: color_mode=9; Make_lists(); Draw(); break;

      case XK_Left:  
	switch(state) {
	case (CTRL+SHIFT): MoveWindow(-10,0); break;
	case (CTRL):       MoveWindow(-1,0); break;
	case (SHIFT):      Yaw(-ROTATE_STEP); break;
	default:           Rotate(0,0,theta-ROTATE_STEP,phi); break;
	}
	Draw_view(); break;
      case XK_Right: 
	switch(state) {
	case (CTRL+SHIFT): MoveWindow(+10,0); break;
	case (CTRL):       MoveWindow(+1,0); break;
	case (SHIFT):      Yaw(+ROTATE_STEP); break;
	default:           Rotate(0,0,theta+ROTATE_STEP,phi); break;
	}
	Draw_view(); break;
      case XK_Up: 
	switch(state) {
	case (CTRL+SHIFT): MoveWindow(0,-10); break;
	case (CTRL):       MoveWindow(0,-1); break;
	case (SHIFT):      Pitch(+ROTATE_STEP); break;
	default:           Rotate(0,0,theta,phi+ROTATE_STEP); break;
	}
	Draw_view(); break;
      case XK_Down:
	switch(state) {
	case (CTRL+SHIFT): MoveWindow(0,+10); break;
	case (CTRL):       MoveWindow(0,+1); break;
	case (SHIFT):      Pitch(-ROTATE_STEP); break;
	default:           Rotate(0,0,theta,phi-ROTATE_STEP); break;
	}
	Draw_view(); break;
      case XK_Page_Down: 
	switch(state) {
	case (CTRL+SHIFT): if (m!=mmax) {m=mmax; Read_fmt(fmt,template,m);}; Draw(); break;
	case (CTRL):       m+=mstep; Read_fmt(fmt,template,m); Draw(); break;
	case (SHIFT):      Roll(+ROTATE_STEP); Draw_view(); break;
	default:           Tilt(psi+ROTATE_STEP); Draw_view(); break;
	}
	break;
      case XK_Page_Up: 
	switch(state) {
	case (CTRL+SHIFT): if (m!=mmin) {m=mmin; Read_fmt(fmt,template,m);}; Draw(); break;
	case (CTRL):       m-=mstep; Read_fmt(fmt,template,m); Draw(); break;
	case (SHIFT):      Roll(-ROTATE_STEP); Draw_view(); break;
	default:           Tilt(psi-ROTATE_STEP); Draw_view(); break;
	}
	break;

      case XK_minus: 
	switch(state) {
	case (CTRL): case (CTRL+SHIFT):
	  distance*=DISTANCE_FAC; setView(theta,phi,psi,distance); Draw_view(); break;
	default:
	  mstep*=-1; Draw_title(); break;
	}
	break;

      case XK_equal:
	switch(state) {
	case (CTRL): case (CTRL+SHIFT):
	  distance/=DISTANCE_FAC; setView(theta,phi,psi,distance); Draw_view(); break;
	default: Assign_par(); break;
	}
	break;

      default: play("Pop");
      }  /* switch(theKeySym) */
      break;

    case EnterNotify:
      /* This case is necessary for window managers which do not set keyboard
       * focus to theWindow when the pointer enters theWindow. */
      /* XSetInputFocus(theDisplay, theWindow, RevertToPointerRoot, CurrentTime);  */
      XSetInputFocus(theDisplay, theWindow, RevertToParent, CurrentTime); 
      break;
      
    case Expose:
      /* Window mapped for the first time and if you uncover some part of the
       * window. If you start paused and you see nothing in the window then
       * its possible that the problem is that the first Expose event is not
       * being caught for some reason. */
      Draw();
      break;

    case ConfigureNotify:
      /* Window size is changed by the user (or the window is initially
       * opened). Note that InitX contains code that constrains the window
       * to be square. */
      myReshape(theEvent.xconfigure.width, theEvent.xconfigure.height);
      break;

    case ButtonPress:
      if (theEvent.xbutton.button == 1) {
	Mouse_down(theEvent.xbutton.x, theEvent.xbutton.y);
      }
      break;

    case ButtonRelease:
      if (theEvent.xbutton.button == 1) {
	Mouse_up();
      }
      break;

    case MotionNotify:
      if (theEvent.xmotion.state & Button1Mask) {
	/* Remove all the MotionNotify events currently in the queue leaving
	 * the last one in theEvent. This ensures the image 'sticks' to the
	 * mouse. */
	while (XCheckWindowEvent(theDisplay,theWindow,
				 PointerMotionMask, &theEvent));
	/* Rotate(theEvent.xmotion.x, theEvent.xmotion.y, 0., 0.); */
	Turn(theEvent.xmotion.x, theEvent.xmotion.y);
	Draw(); 
      }
      break;

    } /* switch (theEvent.type) */

  } /* while (XPending(theDisplay) || (ezmode != MODE_SIMULATING)) */

  /* restore write_filament */
  write_filament = write_filament_save;

  return(0);
}
/* ========================================================================= */

static void InitX (int *winx, int *winy, int width, int height)
{
  /* Initializes X and opens a window. */

  static XVisualInfo           *theVisualInfo;
  static GLXContext            theGLXContext;
  static Colormap              theColormap;
  static int                   theScreen; 
  static int                   theDepth;
  static char                  *theDisplayName = NULL;
  static XEvent                event;
  static Atom                  del_atom;
  static XSizeHints            theSizeHints;
  static XSetWindowAttributes  theSWA;
  static char                  *name = WINDOW_TITLE;
  static int                   num1,num2;
  static int list[] = {GLX_RGBA,
		       GLX_DOUBLEBUFFER,
		       GLX_RED_SIZE, 1,
		       GLX_GREEN_SIZE, 1,
		       GLX_BLUE_SIZE, 1,
		       GLX_ALPHA_SIZE, 1,
		       GLX_DEPTH_SIZE, 1,
		       None } ;

  /* DEPTH and DOUBLE are the important ones.  Perhaps need to add error
   * checking when DOUBLE_BUFFER and DEPTH not available.  In the aux library
   * the first entry in list was GLX_LEVEL, 0, */

  /* Open the display */
  if ((theDisplay = XOpenDisplay(NULL)) == NULL) {
    fprintf(stderr, 
	    "ERROR: Could not open a connection to X on display %s\n",
	    XDisplayName(theDisplayName));
    exit(1);
  }
  if (!glXQueryExtension(theDisplay, &num1, &num2)) {
    fprintf(stderr,
	    "ERROR: No glx extension on display %s\n",
	    XDisplayName(theDisplayName));
    exit(1);
  }

  theScreen     = DefaultScreen(theDisplay);
  theDepth      = DefaultDepth (theDisplay, theScreen);
  theDWidth     = DisplayWidth (theDisplay, theScreen);
  theDHeight    = DisplayHeight(theDisplay, theScreen);

  /* Remember the window size for Save_image */
  WindowWidth=width; WindowHeight=height;

  /* How much space for moving the window without goint beyond screen */
  horspace=theDWidth-WindowWidth;
  vertspace=theDHeight-WindowHeight;


  if (!(theVisualInfo = glXChooseVisual(theDisplay, theScreen, list))) {
    fprintf(stderr, "ERROR: Couldn't find visual");
    exit(-1);
  }
  if (!(theGLXContext = glXCreateContext(theDisplay, theVisualInfo,
					 None, GL_TRUE))) {
    /* Last parameter indicates that, if possible, then render directly to
     * graphics hardware and bypass the X server. This should be faster. */
    fprintf(stderr, "ERROR: Can not create a context!\n");
    exit(-1);
  }

  theColormap = XCreateColormap(theDisplay,
				RootWindow(theDisplay, theVisualInfo->screen),
				theVisualInfo->visual, AllocNone);
  /* AllocAll would generate a BadMatch.  */

  if (!(theColormap)) {
    fprintf(stderr, "ERROR: couldn't create Colormap\n");
    exit(-1);
  }
  theSWA.colormap = theColormap;
  theSWA.border_pixel = 0;
  theSWA.event_mask = (EnterWindowMask | KeyPressMask | StructureNotifyMask | 
		       ButtonPressMask | ButtonReleaseMask | ExposureMask | 
		       PointerMotionMask);

  if (horspace) {
    while (*winx<0) *winx+=horspace;
    while (*winx>=horspace) *winx-=horspace;
  }
  if (vertspace) {
    while (*winy<0) *winy+=vertspace;	
    while (*winy>=vertspace) *winy-=vertspace;
  }
  theWindow = XCreateWindow(theDisplay,
			    RootWindow(theDisplay, theVisualInfo->screen),
			    *winx, *winy, width, height, 0,
			    theVisualInfo->depth, InputOutput,
			    theVisualInfo->visual,
			    CWBorderPixel|CWColormap|CWEventMask, &theSWA);

  if (!(theWindow)) {
    fprintf(stderr, "ERROR: couldn't create X window\n");
    exit(-1);
  }

  /* Remember the window size for Save_image */
  WindowWidth=width; WindowHeight=height;

  /* Set standard window properties.  theWindowName and theIconName are set
   * to Name, which unless you change it (in ezgraph3d.h), it will be
   * EZ-Scroll. */

  XStringListToTextProperty(&name,1,&theWindowName);
  XStringListToTextProperty(&name,1,&theIconName);

  theSizeHints.base_width = width;
  theSizeHints.base_height = height;
  theSizeHints.min_aspect.x = width;   /* Maintain x:y ratio */
  theSizeHints.max_aspect.x = width;
  theSizeHints.min_aspect.y = height;
  theSizeHints.max_aspect.y = height;

  theSizeHints.flags = PSize|PAspect;

  if(!(WM_CTRLS_POS)) theSizeHints.flags |= USPosition;
  /* Setting USPosition here seems to make the WM honor the x and y
   * specified by XCreateWindow above.  Not setting this should give control
   * of position to the WM.  Note that the root window of an application is
   * special in that the WM has special privileges over its properties so
   * this may not work on all platforms.  */

  XSetWMProperties(theDisplay, theWindow, &theWindowName, &theIconName,
		   NULL, 0, &theSizeHints, NULL, NULL);

  /* Express interest in WM killing this application  */
  if ((del_atom = XInternAtom(theDisplay, "WM_DELETE_WINDOW", TRUE)) != None) {
    XSetWMProtocols(theDisplay, theWindow, &del_atom, 1); 
  }

  XMapWindow(theDisplay, theWindow);
  XIfEvent(theDisplay, &event, WaitForNotify, (char *)theWindow);

  glXMakeCurrent(theDisplay, theWindow, theGLXContext);
  /* XSetInputFocus(theDisplay, theWindow, RevertToPointerRoot, CurrentTime);  */
  XSetInputFocus(theDisplay, theWindow, RevertToParent, CurrentTime); 

  /* Print useful information. I suggest printing this at least once */
  if(verbose>1) {
    printf("%s version %d of the X Window System, X%d R%d\n",
	   ServerVendor    (theDisplay),
	   VendorRelease   (theDisplay),
	   ProtocolVersion (theDisplay),
	   ProtocolRevision(theDisplay));

    if(theDepth==1) {
      printf("Color plane depth...........%d (monochrome)\n", theDepth);
    }
    else {
      printf("Color plane depth...........%d \n",             theDepth);
    }

    printf("Display Width...............%d \n", theDWidth);
    printf("Display Height..............%d \n", theDHeight);
    printf("The display %s\n", XDisplayName(theDisplayName));
  }
}
/* ========================================================================= */

static Bool WaitForNotify(Display *d, XEvent *e, char *arg) 
{
  /*  As seen in the Porting Guide. */
  return (e->type == MapNotify) && (e->xmap.window == (Window)arg);
}
/* ========================================================================= */

void QuitX (void)
{
  if(GRAPHICS)
    XCloseDisplay(theDisplay);
  return;
}
/* ========================================================================= */

/* Save to a file a png image of what is currently on the screen using glReadPixels + netpbm converter. */
static void Save_image (void) {
  static int num = 0;
  static int m_prev = 0;
  static char cmd[4096];
  int bufsize=WindowWidth*WindowHeight*3;
  unsigned char *buf;
  char *fifoname=tempnam(NULL,NULL);
  pid_t child_pid;
  FILE *fifo;
  int status;

  if (!theWindow) return;
  if (-1==mkfifo(fifoname,0600)) {perror("Save_image could not make a fifo"); return;}
  if (m != m_prev) num=0;

  switch (child_pid=fork()) {
  case -1:
    perror("pipeto could not fork");
    return;
  case 0:
    sprintf(cmd,"cat %s | pnmflip -tb | pnmtopng > %s%06d-%02d.png",fifoname,"snap",m,num);
    system(cmd);
    _exit(0);
  default:
    if (NULL==(fifo=fopen(fifoname,"w"))) {perror("Save_image could not write to fifo"); return;}
    fprintf(fifo,"P6\n%d %d\n%d\n",WindowWidth,WindowHeight,255);
    XRaiseWindow(theDisplay,theWindow);
    glFlush(); /* printf("glFlush done\n"); */
    buf=malloc(bufsize);
    glReadPixels(0,0,WindowWidth,WindowHeight,GL_RGB,GL_UNSIGNED_BYTE,buf);
    fwrite(buf,1,bufsize,fifo);
    if (0!=fclose(fifo)) perror("Save_image could not close fifo");
    waitpid(child_pid,&status,0);
    if (0==(WIFEXITED(status))) fprintf(stderr,"Save_image child status %08x\n",status);
    free(buf);
    unlink(fifoname);
    m_prev=m; 
    num++;
  }
}
/* ========================================================================= */

static void  before_drawing (void) {
  /* printf("before drawing\n"); */
  if (verbose>=4) play("Tink");
  *busychar=' ';
  XStringListToTextProperty(&pname,1,&theWindowName);
  XSetWMName(theDisplay, theWindow, &theWindowName);
  /* glFlush(); */
  XFlush(theDisplay);
}
/* ========================================================================= */

static void  after_drawing (void) {
  /* printf("after drawing\n"); */
  *busychar='*';
  XStringListToTextProperty(&pname,1,&theWindowName);
  XSetWMName(theDisplay, theWindow, &theWindowName);
  /* glFlush(); */
  XFlush(theDisplay);
  if (verbose>=4) play("Pop");
}
/* ========================================================================= */
