/* ------------------------------------------------------------------------- */
/* ezmarching.c -- Efficient implementation of the Marching Cubes Algorithm
 * first published by Bill Lorensen (1987).
 *
 * Copyright (C) 1996 - 1998, 2006, 2007 Dwight Barkley and Matthew Dowle
 *
 * RCS Information
 * ---------------------------
 * $Revision: 1.5.1.1 $
 * $Date: 2007/05/07 10:07:03 $
 * ------------------------------------------------------------------------- */

/* Modifications for EZView: 2010-12, V. N. Biktashev at exeter.ac.uk        */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glx.h>

#include "ezscroll.h"    
#include "ezgraph3d.h"
#include "ezmarching.h"

/* -------------------------------------------------------------------------
 *
 * This file contains all graphics functions that compute the iso-surfaces
 * and filaments, and render these.
 *
 * The important things to know about this file are:
 * 
 * (1) All functions containing OpenGL calls start with Draw_.  These
 * functions and Marching_cubes() are probably the only ones you would
 * need to change to affect the look of the graphics (contour colors etc.)
 *
 * (2) The U and V contours values are defined in ezmarching.h.  The filament
 * is defined as the intersection of these iso-surfaces.
 *
 * (3) There are three states the draw_mode can be in:
 *   OFF:       glEnd() has been called and nothing being passed to OpenGL.
 *   LINES:     glBegin(GL_LINES) has been called and points on line 
 *              segments are being passed.
 *   TRIANGLES: glBegin(TRIANGLES) has been called and triangle vertices 
 *              are being passed.
 * (VNB: also: CURVES, FANS and STRIPS)
 *
 * (4) The last approx 1/4 of the code is devoted to initialization,
 * i.e. setting up the lookup table.  You shouldn't touch this.
 *
 * May 2007: added computation of surface normals for nicer 3D visualization.
 *
 * ------------------------------------------------------------------------- */


/* 
 * Global variables for this file only 
 * ----------------------------------- */

static CubeEdge        triangle_table[256][MAX_TRIANGLE_LIST_LENGTH];
                           /* triangle_table is the marching cubes lookup
			    * table containing triples of edges which define
			    * each triangle.  */

static CubeEdge        edge_table[256][MAX_EDGE_LIST_LENGTH];
                           /* Same as triangle_table but without repetitions
			    * of edges. */

static CubeEdge        *triangle_list[2];
                           /* triangle_list[U_FIELD] and
			    * triangle_list[V_FIELD] are used when filament
			    * plotting to find common lines of the
			    * triangles. */

static GLReal          vertex[2][13][3];
                            /* Triangle vertices in real world space for each
			     * edge in each volume. When just surface drawing
			     * we only use the U or V part of the array. When
			     * filament drawing we use both. */

static GLReal          normals[13][3];
                            /* Surface normals at the triangle vertices. */

/* static GLReal          contour[2]; */
                            /* The U and V values of the iso-surfaces. */

static GLReal          marching_h; 
                            /* Size of marching cube in graphics coordinates */

static GLReal 	       convert_to_phy;
                            /* Convert from graphics to physical coordinates */

static GLReal          pos[3];
                            /* Position of the 3rd vertex of the current
			     * marching cube in graphics coordinates. */

static Axis            axis[13]  = {0,Z,Y,Z,Y,Z,Y,Z,Y,X,X,X,X}; 
                            /* Given a cube edge, axis tells you which
			     * coordinate axis the edge is on. */

static unsigned int    ii,jj,kk;
                            /* Position of the 3rd vertex of the current
			     * marching cube on the simulation grid. */

static unsigned int    inc; 
                           /* The length of the marching (graphics) cube in
			    * terms of the simulation grid. The marching cube
			    * is defined by (ii,jj,kk) and
			    * (ii-inc,jj-inc,kk-inc).  Must be >= 1. */

static int             draw_mode=OFF;
                            /* draw_mode can be in one of three states. start
			     * with it off */

/* static Bool            filament_only;  */
                            /* compute filament only */

/* static Bool            show_field; */
                            /* draw an iso-surface on screen */

/* 
 * Private functions 
 * ----------------- */

/* OpenGL specific drawing functions */
static void       Draw_triangles          (int lu,int lv,Real vmin,Real vmax,Real vc);
/* static void       Draw_filament           (int clipping, GLReal point[2][3]); */
static void Register_segment(GLReal point[2][3]);
/* static void Draw_filament_finish (int clipping); */
static void Register_chains(int clipping,GLReal conver_to_phy);


static void       Draw_bounding_box       (int clipping);
#if MARKER
static void       Draw_marker             (int clipping);
#endif
/* static void       Draw_gridsphere         (int clipping, Real centre[3], Real radius); */
static void       Draw_sphere             (int clipping, GLReal centre[3], Real radius);

/* Functions for computing iso-surfaces and filaments */
static void       Compute_Surface_and_Filament(void);
static void       Filament_in_cube        (int lu, Real uconst, int lv, Real vconst);

static void       Surface_in_cube 	  (int do_surface, int do_filament,
					   int lu,Real uconst, 
					   int lv,Real vmin,Real vmax,Real vconts);
static Bool       Find_two_pts            (GLReal point[2][3], 
					   GLReal point_r[4], 
					   GLReal p[3], GLReal dir[3]);
static void       Set_relative_edge_pos   (int inc);
static GLReal     Contour_normal_intersect(int layer, Real contour, CubeEdge edge, 
					   GLReal *normal);

static void       Set_draw_mode_off       (void);
static void       Set_draw_mode_lines     (int clipping, GLReal lwidth);
static void       Set_draw_mode_curves    (int clipping, GLReal lwidth);
static void       Set_draw_mode_triangles (int clipping);
static void       Set_draw_mode_fan       (int clipping);
static void       Set_draw_mode_strip     (int clipping);

/*==================================*/
/* Functions used in initialization */
static CubeIndex  Rotate_edge_list        (CubeIndex index, int direction);
static CubeIndex  Rotate_edge_list_x      (CubeIndex index);
static CubeIndex  Rotate_edge_list_y      (CubeIndex index);
static void       Rotate_diagonal         (CubeIndex index);
static void       Do_all_orientations     (CubeIndex index);
static void       Generate_edge_table     (void);
static void       Print_list              (CubeEdge *p);

/*===ORIGINAL VALUE FUNCTION====================================*/
/* Access to data, with account of taboo bytes designating void */
static Real value(int l, int i, int j, int k,Real dflt) {
  int nneib, rad, di, dj, dk;
  Real vsum;
  static int times_reported=0;
  Real v=Fields(l,i,j,k);

  if (v==taboo) {
    for(rad=1;rad<NX;rad++) {
      nneib=0;
      vsum=0.0;
      for (di=-rad;di<=rad;di++) {
	for (dj=-rad;dj<=rad;dj++) {
	  for (dk=-rad;dk<=rad;dk++) {
	    if (i+di<1) continue;
	    if (i+di>NX) continue;
	    if (j+dj<1) continue;
	    if (j+dj>NY) continue;
	    if (k+dk<1) continue;
	    if (k+dk>NZ) continue;
	    v=Fields(l,i+di,j+dj,k+dk);
	    if (v==taboo) continue;
	    vsum+=v;
	    nneib++;
	  }
	}
      }
      if (nneib) {
	v=vsum/nneib;
	break;
      }
    }
  }
  if (v==taboo && nneib==0) {
    if (times_reported<=10) {
      printf("could not find good %d-value around (%d,%d,%d)\n",l,i,j,k);
      if (times_reported==10)
	printf("(further similar reports suppressed)\n");
      times_reported++;
    }
    v=dflt;
  }
  return v;
}
/*=================*/

/*=values2 is a clone of values() above, in an attempt to make it draw the geomtry =*/
/* Access to data, with account of taboo bytes designating void */
/*
Just returns the value of Fields for now.
*/
static Real value_geom(int l, int i, int j, int k,Real dflt) {
  int nneib, rad, di, dj, dk;
  Real vsum;
  static int times_reported=0;
  Real v=Fields(l,i,j,k);
  return v;
}
/*=================*/


static Real istissue(int i, int j, int k) {
  if (Fields(ulayer,i,j,k)==taboo)
    return 0.0;
  else
    return 1.0;
}


/* ========================================================================= */


#if TRACE
extern long ntrace;
extern long *tracet;
extern Real *tracex;
extern Real *tracey;
extern Real *tracez;
#endif

void Marching_cubes (unsigned int resolution) {
  if (bbox_wt) Draw_bounding_box(clipping);
  #if MARKER
  Draw_marker(clipping);
  #endif

  if (show_surface || show_filament || write_filament) {

    inc = resolution;
    marching_h = inc*plot_length[0]/(imax-imin+1);
    convert_to_phy = grid_h*(inc/marching_h);
    Set_relative_edge_pos(inc);
    
    /* If field == NO_FIELD then just the filament is to be found.  In
     *   this case can set and leave the draw mode as lines.  Set field
     *   to U (to find filament we must first find an iso-surface) and at
     *   end re-set to NO_FIELD.  
     * Otherwise we will be drawing triangles. */

    /* VNB: setting drawing modes is now delegated to drawing routines */
    /* if (!show_surface) {            */
    /*   Set_draw_mode_lines(clipping, flm_wt); */
    /* } else { */
    /*   Set_draw_mode_triangles(clipping); */
    /* } */
   
    /* Compute iso-surface and/or filament */
    Compute_Surface_and_Filament();
    
    /* Finish up */
    Set_draw_mode_off();
  }
#if TRACE
  if (tracelen) {
    long n;
    GLfloat f, dx, dy, dz;
    Set_draw_mode_curves(clipping,trf_wt);
    for (n=0;n<ntrace;n++) {
      if (tracet[n]<m*traceint-tracelen) continue;
      if (tracet[n]>m*traceint) break;
      f=(tracet[n]-(m*traceint-tracelen))/(1.0*tracelen);
      glLineWidth(trf_wt+f*(trl_wt-trf_wt));
      GLCOLOR4(
        trf_r+f*(trl_r-trf_r),
        trf_g+f*(trl_g-trf_g),
        trf_b+f*(trl_b-trf_b),
        trf_a+f*(trl_a-trf_a)
      );
      if (verbose) printf("m=%d tracet=%ld\n",m,tracet[n]);
      dx=trf_dx*(1-f)+trl_dx*f;
      dy=trf_dy*(1-f)+trl_dy*f;
      dz=trf_dz*(1-f)+trl_dz*f;
      glVertex3f(
        (GLfloat)(plot_ini[0]+((tracex[n]+dx-imin+1)/(imax-imin+2))*plot_length[0]),
	(GLfloat)(plot_ini[1]+((tracey[n]+dy-jmin+1)/(jmax-jmin+2))*plot_length[1]),
	(GLfloat)(plot_ini[2]+((tracez[n]+dz-kmin+1)/(kmax-kmin+2))*plot_length[2])
      );
    }
    Set_draw_mode_off();
  }
#endif
}
/* ========================================================================= */

static void Draw_triangles (int lu,int lv,Real vmin,Real vmax,Real vc) {
  GLReal red, green, blue, alpha;
  Real vvalue;
  Real wvalue;
  int n;

  Set_draw_mode_triangles(clipping);

  /* -----------------------------------------------------------------
   *                    Set the iso-surface color.
   * Can also choose not to render some triangles.  Examples are given
   * Note: I only color at the marching cube level, i.e. all triangles
   * within a given marching cube get the same color.  One could color
   * at the individual triangle level (inside the while loop).
   * ----------------------------------------------------------------- */

  vvalue=value(lv,ii,jj,kk,vc);

  if (remove_backs) {
    /* Do not draw triangles if v(ii,jj,kk) > V_CONT */
    if( vvalue > vc) return;
  }

  switch(color_mode) {
  case 0:  /* Color (yellow-green) according to other field (vlayer)*/
    red   = (vmax-vvalue)/(vmax-vmin);
    green = 0.5;
    blue  = 0.;
    alpha = alphamax;
    break;

  case 1: /* Color (red-blue) according to other field */
    red   = (vmax-vvalue)/(vmax-vmin);
    blue  = (vvalue-vmin)/(vmax-vmin);
    green = red*blue*4;
    alpha = alphamin+(alphamax-alphamin)*red; /* 0.3+0.7*green*green; */
    break;

  case 2: /* Fixed color (orange), transparency according to other field */
    red   = 1.;
    green = 0.5;
    blue  = 0;
    alpha = alphamin+(alphamax-alphamin)*(vmax-vvalue)/(vmax-vmin);
    break;

  case 3: /* As 1, with total brightness constant */
    red   = (vmax-vvalue)/(vmax-vmin);
    red=(red<0)?0:(red>1)?1:(red*red);
    blue  = (vvalue-vmin)/(vmax-vmin);
    blue=(blue<0)?0:(blue>1)?1:(blue*blue);
    green = 1.0 - red - blue;
    alpha = alphamin+(alphamax-alphamin)*red;
    break;

  case 4: /* Color (red-blue) according to two other TWO fields */
    wvalue= value(wlayer,ii,jj,kk,vc);
    red   = (vvalue-vmin)/(vmax-vmin);
    blue  = (wmax-wvalue)/(wmax-wmin);
    green = 0;
    alpha = alphamin+(alphamax-alphamin)*red;
    break;

/*
SK. 12/12/12
To viz the geomtry tissue types.
This requires putting in values from the 3rd layer of the ppmout_het output
into wvalue, and revising value function (another copy) to get the tissue types.
*/

  case 5: /* Color according to geometry; two other TWO fields */
/*    printf("%f %f \n",value_geom(wlayer,ii,jj,kk,vc),value_geom(vlayer,ii,jj,kk,vc)); */
    wvalue= value_geom(wlayer,ii,jj,kk,vc);
    red   = (vvalue-vmin)/(vmax-vmin);
    blue  = (wmax-wvalue)/(wmax-wmin);
    green = 0;
    alpha = alphamin+(alphamax-alphamin)*red;
    break;

  default: /* Color according to position in space, Useful if not computing normals */
    red   = pos[Y]/plot_length[1]; 
    green = pos[Z]/plot_length[2]; 
    blue  = pos[X]/plot_length[0];
    alpha = alphamax;
    break;

  }

  GLCOLOR4(red, green, blue, alpha);

  /* Send OpenGL the positions of each triangle vertex.  Every group of 3
   * vertices is interpreted as defining one triangle. The triangle table is
   * organized so that all we need do now is pass all the vertices in the
   * list to OpenGL. */

  n = 0;
  while (triangle_list[U_FIELD][n] != END) { 
    GLNORMAL3V(normals[triangle_list[U_FIELD][n]]);
    GLVERTEX3V(vertex[U_FIELD][triangle_list[U_FIELD][n]]);
    n++;
  }
}
/* ========================================================================= */

/*********************************************************/
/* Collecting filament segments into continuous "curves" */

/* The Marching Cube algorithm generates points in duos. */
typedef struct listnode {
  GLReal piece[2][3];
  struct listnode *prev;
  struct listnode *next;
} listitemtype;
/* This is transformed into chains consisting of solo points */
typedef struct chainnode {
  GLReal point[3];
  struct chainnode *prev;
  struct chainnode *next;
} chainitemtype;
static listitemtype *newlistitem(void) {
  listitemtype *p=calloc(1,sizeof(listitemtype));
  if (!p) {
    fprintf(stderr,"could not alloc memory for list item; abort\n");
    exit(1);
  }
  return p;
}
static chainitemtype *newchainitem(void) {
  chainitemtype *p=calloc(1,sizeof(chainitemtype));
  if (!p) {
    fprintf(stderr,"could not alloc memory for chain item; abort\n");
    exit(1);
  }
  return p;
}
static void pointcopy(chainitemtype *dest, GLReal src[3]) {
  int i;
  if (!dest) return;
  if (!src) return;
  for(i=0;i<3;i++) dest->point[i]=src[i];
}
/* are two given points close enough to be considered the same? */
static int closepoints(chainitemtype *item, GLReal point[3]) {
  GLReal small=1.e-4; /* even this still breaks them up */
  int i;
  for (i=0;i<3;i++) if (fabs(item->point[i]-point[i])>small) return 0;
  return 1;
}
static listitemtype *listfirst;
static listitemtype *listlast;
/* static void Draw_filament_finish (int clipping) {} */
static void Register_chains (int clipping, GLReal conver_to_phy) {
  listitemtype *listnext;
  listitemtype *listitem;
  chainitemtype *chainfirst;
  chainitemtype *chainlast;
  chainitemtype *addbefore;
  chainitemtype *addafter;
  chainitemtype *chainitem;
  chainitemtype *chainnext;
  int trymore, matched;


  #if READFLM
  if (flmtemplate && *flmtemplate) {
    #define BUFLEN 4096
    char buf[BUFLEN];
    FILE *f;
    float x,y,z;
    GLReal point[3];
    sprintf(buf,flmtemplate,m);
    fprintf(stderr,"reading from %s\n",buf);
    f=fopen(buf,"r");
    if (!f) return;
    GLCOLOR3(flm_r, flm_g, flm_b);
    if (flm_balls!=1) Set_draw_mode_curves(clipping,flm_wt);
    while (!feof(f)) {
      fgets(buf,BUFLEN,f);
      if (3!=sscanf(buf,"%g %g %g\n",&x,&y,&z)) continue;
      point[0]=x/convert_to_phy;
      point[1]=y/convert_to_phy;
      point[2]=z/convert_to_phy;
      if (flm_balls)
	Draw_sphere(clipping,point,flm_wt);
      else
	GLVERTEX3V(point);
    }
    fclose(f);
    return;
    #undef BUFLEN
  }
  #endif

  while (NULL!=listfirst) {

    /* start a new continuous chain from the first available segment */
    chainfirst=newchainitem();
    chainlast=newchainitem();

    pointcopy(chainfirst,listfirst->piece[0]);
    chainfirst->next=chainlast;
    chainfirst->prev=NULL;

    pointcopy(chainlast,listfirst->piece[1]);
    chainlast->next=NULL;
    chainlast->prev=chainfirst;

    /* unlink that segment from the original list */
    listnext=listfirst->next;
    if (listnext) listnext->prev=NULL;
    free(listfirst);
    if (listnext) {
      listfirst=listnext;
    } else {
      listfirst=listlast=NULL;
    }

    /* try to grow the chain by trying out all available segments one by one */
    do {

      /* loop through the rest of the original list */
      listitem=listfirst;
      trymore=0;
      while(listitem!=NULL) {
	matched=1;

	/* there are four ways a given segment may match the existing chain */
	if (closepoints(chainfirst,listitem->piece[0])) {
	  addbefore=newchainitem();
	  pointcopy(addbefore,listitem->piece[1]);
	  addbefore->next=chainfirst;
	  addbefore->prev=NULL;
	  chainfirst->prev=addbefore;
	  chainfirst=addbefore;
	} else if (closepoints(chainfirst,listitem->piece[1])) {
	  addbefore=newchainitem();
	  pointcopy(addbefore,listitem->piece[0]);
	  addbefore->next=chainfirst;
	  addbefore->prev=NULL;
	  chainfirst->prev=addbefore;
	  chainfirst=addbefore;
	  trymore=1;
	} else if (closepoints(chainlast,listitem->piece[0])) {
	  addafter=newchainitem();
	  pointcopy(addafter,listitem->piece[1]);
	  addafter->prev=chainlast;
	  addafter->next=NULL;
	  chainlast->next=addafter;
	  chainlast=addafter;
	} else if (closepoints(chainlast,listitem->piece[1])) {
	  addafter=newchainitem();
	  pointcopy(addafter,listitem->piece[0]);
	  addafter->prev=chainlast;
	  addafter->next=NULL;
	  chainlast->next=addafter;
	  chainlast=addafter;
	} else {
	  matched=0;
	}
	if (matched) {
	  /* remove the matching segment from the original list */
	  /* taken care in case it is the first or the last one there */
	  if (listitem->prev!=NULL) {
	    listitem->prev->next=listitem->next;
	  } else {
	    listfirst=listitem->next;
	  }
	  if (listitem->next!=NULL) {
	    listitem->next->prev=listitem->prev;
	  } else {
	    listlast=listitem->prev;
	  }
	  trymore=1;
	}
	listnext=listitem->next;
	/* free(listitem); - keep it there, it will match another time */
	listitem=listnext;
      };
    } while(trymore);

    /* Now we can output the continuous chains. */
    /* This is either by lines or by balls. */
    if (chainfirst) {
      if (show_filament) {
	GLCOLOR3(flm_r, flm_g, flm_b);
	if (flm_balls!=1) Set_draw_mode_curves(clipping,flm_wt);
      }
      chainitem=chainfirst;
      do { /* output all chain points */
	if (write_filament) {
	  Write_filament_point(convert_to_phy*chainitem->point[0], 
			       convert_to_phy*chainitem->point[1],
			       convert_to_phy*chainitem->point[2]);
	}
	if (show_filament) {
	  if (flm_balls)
	    Draw_sphere(clipping,chainitem->point,flm_wt);
	  else
	    GLVERTEX3V(chainitem->point);
	}
	chainnext=chainitem->next;
	if (chainnext) chainnext->prev=NULL;
	free(chainitem);
	chainitem=chainnext;
      } while (chainitem!=NULL);
      /* all chain points plotted/written */
      if (write_filament) 
	Write_filament_segment(); /* to distinguish chains in the output file */
    } /* if chainfirst */
  } /* while listfirst */
  Write_filament_frame(); /* to distinguish frames in the output file */
}
/* ========================================================================= */


/* Add the given piece to the linked list of segments */
static void Register_segment (GLReal point[2][3]) {
  int j;
  listitemtype *listitem;
  listitemtype *lastbutone;
  #if READFLM
  if (flmtemplate && *flmtemplate) return;
  #endif

  listitem=newlistitem();
  for(j=0;j<3;j++){
    listitem->piece[0][j] = point[0][j];
    listitem->piece[1][j] = point[1][j]; 
  }
  if (listfirst && listlast) {
    lastbutone=listlast;
    listlast=listitem;
    listlast->prev=lastbutone;
    listlast->next=NULL;
    lastbutone->next=listlast;
  } else if (listfirst || listlast) {
    fprintf(stderr,"this cannot be\n");
    exit(1);
  } else {
    listitem->prev=listitem->next=NULL;
    listfirst=listlast=listitem;
  }
}
/* ========================================================================= */

/* the box with axes labels */
void Draw_bounding_box (int clipping) {
  Real x0=plot_ini[0]; 
  Real xm=plot_ini[0]+plot_length[0]*0.5;
  Real x1=plot_ini[0]+plot_length[0];
  Real y0=plot_ini[1]; 
  Real ym=plot_ini[1]+plot_length[1]*0.5;
  Real y1=plot_ini[1]+plot_length[1];
  Real z0=plot_ini[2]; 
  Real zm=plot_ini[2]+plot_length[2]*0.5;
  Real z1=plot_ini[2]+plot_length[2];

  Real cw=0.02;         /* char width compared to plot size */
  Real ch=sqrt(2.0)*cw; /* char height compared to plot size */
  Real hh=0.5*ch;       /* half-height */
  Real sq=sqrt(0.5);    /* to make 45deg slopes */
  Real d=0.5*ch*sq;     /* dist from axis */

  /* the box */
  Set_draw_mode_lines(clipping, bbox_wt);

  GLCOLOR4(bbox_r, bbox_g, bbox_b, bbox_a);

  GLVERTEX3(x0,y0,z0);  
  GLVERTEX3(x1,y0,z0);
  GLVERTEX3(x1,y0,z0);  
  GLVERTEX3(x1,y1,z0);
  GLVERTEX3(x1,y1,z0);
  GLVERTEX3(x0,y1,z0);
  GLVERTEX3(x0,y1,z0);
  GLVERTEX3(x0,y0,z0);

  GLVERTEX3(x0,y0,z0);
  GLVERTEX3(x0,y0,z1);
  GLVERTEX3(x1,y0,z0);
  GLVERTEX3(x1,y0,z1);
  GLVERTEX3(x1,y1,z0);
  GLVERTEX3(x1,y1,z1);
  GLVERTEX3(x0,y1,z0);
  GLVERTEX3(x0,y1,z1);

  GLVERTEX3(x0,y0,z1);  
  GLVERTEX3(x1,y0,z1);
  GLVERTEX3(x1,y0,z1);  
  GLVERTEX3(x1,y1,z1);
  GLVERTEX3(x1,y1,z1);  
  GLVERTEX3(x0,y1,z1);
  GLVERTEX3(x0,y1,z1);  
  GLVERTEX3(x0,y0,z1);

  /* the axes labels */
  Set_draw_mode_lines(0,1.5*bbox_wt);
  /* X */
  GLVERTEX3(xm-0.5*cw ,y0      -d,z0      -d);
  GLVERTEX3(xm+0.5*cw ,y0-d-sq*ch,z0-d-sq*ch);
  GLVERTEX3(xm+0.5*cw ,y0      -d,z0      -d);
  GLVERTEX3(xm-0.5*cw ,y0-d-sq*ch,z0-d-sq*ch);
  /* Y */
  GLVERTEX3(x0-d-sq*hh,ym        ,z0-d-sq*hh);
  GLVERTEX3(x0-d      ,ym+0.5*cw ,z0-d      );
  GLVERTEX3(x0-d-sq*ch,ym+0.5*cw ,z0-d-sq*ch);
  GLVERTEX3(x0-d      ,ym-0.5*cw ,z0-d      );
  /* Z */
  GLVERTEX3(x0-d      ,y0-d      ,zm-0.5*cw );
  GLVERTEX3(x0-d      ,y0-d      ,zm+0.5*cw );
  GLVERTEX3(x0-d      ,y0-d      ,zm+0.5*cw );
  GLVERTEX3(x0-d-sq*ch,y0-d-sq*ch,zm-0.5*cw );
  GLVERTEX3(x0-d-sq*ch,y0-d-sq*ch,zm-0.5*cw );
  GLVERTEX3(x0-d-sq*ch,y0-d-sq*ch,zm+0.5*cw );

}
/* ========================================================================= */

#if MARKER
/* coords start with 1 and end with NQ, and 1 is the min index for output in beatbox */
#define gridX(x) ((x-imin)*plot_length[0]/(imax-imin+1))
#define gridY(y) ((y-jmin)*plot_length[1]/(jmax-jmin+1))
#define gridZ(z) ((z-kmin)*plot_length[2]/(kmax-kmin+1))
#define gridvertex(x,y,z) GLVERTEX3(gridX(x),gridY(y),gridZ(z))
void Draw_marker (int clipping) {
  if (!marker_size) return;

  Set_draw_mode_lines(clipping, marker_wt);

  GLCOLOR4(marker_r, marker_g, marker_b, marker_a);

  gridvertex(marker_x+marker_size,marker_y,marker_z);
  gridvertex(marker_x-marker_size,marker_y,marker_z);

  gridvertex(marker_x,marker_y+marker_size,marker_z);
  gridvertex(marker_x,marker_y-marker_size,marker_z);
 
  gridvertex(marker_x,marker_y,marker_z+marker_size);
  gridvertex(marker_x,marker_y,marker_z-marker_size);

  if (verbose) {
    int l;
    int x=floor(marker_x+0.5);
    int y=floor(marker_y+0.5);
    int z=floor(marker_z+0.5);
    printf("(x,y,z)=(%d,%d,%d) u=(",x,y,z);
    for (l=0;l<nlread;l++) 
      printf(FFMT"%s",Fields(l,x,y,z),((l==nlread-1)?")\n":","));
  }
}
#undef gridvertex
#undef gridZ
#undef gridY
#undef gridX
/* ========================================================================= */
#endif

/* Draw a "sphere" with center at given plot coords, with filament colour */
#define plotvertex(x,y,z) GLVERTEX3(c[X]+x,c[Y]+y,c[Z]+z)
/* "physical" spherical coords: inclination theta, azimuth phi */
#define spvertex(phi,theta) \
  GLNORMAL3(sin(theta)*cos(phi),sin(theta)*sin(phi),cos(theta));	\
  plotvertex(r*sin(theta)*cos(phi),r*sin(theta)*sin(phi),r*cos(theta))
#define spnormal(phi,theta) GLNORMAL3(sin(theta)*cos(phi),sin(theta)*sin(phi),cos(theta))
void Draw_sphere (int clipping, GLReal c[3], Real radius) {
  int nt=5;
  int np=10;
  int t, p;
  double theta, theta0, theta1, phi;
  double dtheta=M_PI/nt;
  double dphi=2.0*M_PI/np;
  int nmax = max(max(NX,NY),NZ);
  double r=radius/(nmax-1);

  if (r<=0) return;

  GLCOLOR3(flm_r, flm_g, flm_b);

  /* Northern pole fan */
  Set_draw_mode_fan(clipping);
  plotvertex(0,0,r);
  theta=dtheta;
  for (p=0;p<=np;p++) {
    phi=(p==np)?0:p*dphi; /* to avoid gaps due to round-off */
    spvertex(phi,theta);
    spnormal(phi+0.5*dphi,0.5*dtheta);
  }

  /* Southern pole fan */
  Set_draw_mode_fan(clipping);
  plotvertex(0,0,-r);
  theta=M_PI-dtheta;
  for (p=0;p<=np;p++) {
    phi=(p==np)?0:p*dphi; /* to avoid gaps due to round-off */
    spvertex(phi,theta);
    spnormal(phi+0.5*dphi,M_PI-0.5*dtheta);
  }
  
  /* Intermediate latitude strips */
  for (t=1;t<nt-1;t++) {
    theta0=t*dtheta;
    theta1=(t+1)*dtheta;
    Set_draw_mode_strip(clipping);
    for (p=0;p<=np;p++) {
      phi=(p==np)?0:p*dphi; /* to avoid gaps due to round-off */
      spvertex(phi,theta0);
      spvertex(phi,theta1);
      spnormal(phi+0.5*dphi,0.5*(theta0+theta1));
    }
  }
}
#undef spvertex
#undef plotvertex
/* ========================================================================= */


static void Compute_Surface_and_Filament (void) {
  /* cube counters */
  int i, j, k, idir, jdir, kdir, istart, jstart, kstart, istop, jstop, kstop;
  float small=0.1;
  int do_filament;

  /* these counting sequences are to be revised with account of psi angle */
  if (sin(theta*M_PI/180)*sin(phi*M_PI/180)<=0) {
    istart=imin;idir=+1;istop=floor((imax+small)/inc);
  } else {
    istop=imin;idir=-1;istart=floor((imax+small)/inc);
  }

  if (cos(theta*M_PI/180)<=0) {
    jstart=jmin;jdir=+1;jstop=floor((jmax+small)/inc);
  } else {
    jstop=jmin;jdir=-1;jstart=floor((jmax+small)/inc);
  }

/*   if (sin(phi*M_PI/180)>0) */
    {kstart=kmin;kdir=+1;kstop=floor((kmax+small)/inc);}
/*   else                         */
/*     {kstop=1;kdir=-1;kstart=floor((NZ-1+small)/inc);} */

  for (i=istart; (idir*i)<=(idir*istop); i+=idir) {
    ii=1+inc*i;
    pos[X]=marching_h*i;

    /* Each triangle vertex has only one linearly interpolated component
     * (coordinate). The other 2 are vertices lie on a cube edge and are
     * known.  So for this Y-Z plane, we already know the X component of all
     * the edges not parallel to the X axis. The vertices on the edges
     * parallel to the X axis will be linearly interpolated as necessary
     * later. */

    vertex[U_FIELD][1][X] = 
    vertex[U_FIELD][2][X] = 
    vertex[U_FIELD][3][X] = 
    vertex[U_FIELD][4][X] = pos[X];
    vertex[U_FIELD][5][X] = 
    vertex[U_FIELD][6][X] = 
    vertex[U_FIELD][7][X] = 
    vertex[U_FIELD][8][X] = pos[X] - marching_h;

/*     pos[Y] = 0.0; */
/*     for (jj=1+inc; jj<=NY; jj+=inc) {} */
/*       pos[Y] += marching_h; */

    for (j=jstart; (jdir*j)<=(jdir*jstop); j+=jdir) {
      jj=1+inc*j;
      pos[Y]=marching_h*j;

    
      /* Similar to above, we can set the components of each edge not on the
	 Y axis. */

      vertex[U_FIELD][1][Y]  = 
      vertex[U_FIELD][5][Y]  = 
      vertex[U_FIELD][9][Y]  = 
      vertex[U_FIELD][10][Y] = pos[Y] - marching_h;
      vertex[U_FIELD][3][Y]  = 
      vertex[U_FIELD][7][Y]  = 
      vertex[U_FIELD][11][Y] = 
      vertex[U_FIELD][12][Y] = pos[Y];

/*       pos[Z] = 0.0; */
/*       for (kk=1+inc; kk<=NZ; kk+=inc) {} */
/* 	pos[Z] += marching_h; */

      for (k=kstart; (kdir*k)<=(kdir*kstop); k+=kdir) {
	kk=1+inc*k;
	pos[Z]=marching_h*k;

	do_filament=show_filament||write_filament;
	if (ulayer==layer1 && vlayer==layer2 && uc==const1) {
	  Surface_in_cube(show_surface,do_filament,ulayer,uc,vlayer,vmin,vmax,const2);
	} else {
	  if (show_surface) 
	    Surface_in_cube(1,0,ulayer,uc,vlayer,vmin,vmax,const2);
	  if (do_filament)
	    Surface_in_cube(0,1,layer1,const1,layer2,vmin,vmax,const2);
	}
      } /* for k */
    } /* for j */
  } /* for i */
  /* if(show_filament) Draw_filament_finish(clipping); */
  /* if(write_filament) Write_filament_data_break(); */
  if(show_filament || write_filament) Register_chains(clipping,convert_to_phy);
}
/* ========================================================================= */


/* Calculate the index for the current cube for the given,
 * and draw the piece of surface and/or filament in it, as appropriate. 
 * Recall, the cube is defined by (ii,jj,kk) to (ii-inc,jj-inc,kk-inc)
 * (which are all static globals in this file). 
 * The index considers the cube vertex (ii,jj,kk) to be bit 3 of the
 * index.
 */
void Surface_in_cube (int do_surface, int do_filament,
		      int lu,Real uconst,int lv,Real vmin,Real vmax,Real vconst) {
  static CubeIndex  index, other_index;
  static CubeEdge   edge;
  static int        n;
  int omit; 
  int di, dj, dk;
  static int extra=0; /* consider playing with this? */

  /* contour[U_FIELD]=uconst; */
  /* contour[V_FIELD]=vconst; */

  index =
    ((Fields(lu,ii    ,jj-inc,kk-inc) >= uconst)     ) |
    ((Fields(lu,ii    ,jj-inc,kk)     >= uconst) << 1) |
    ((Fields(lu,ii    ,jj    ,kk)     >= uconst) << 2) |
    ((Fields(lu,ii    ,jj    ,kk-inc) >= uconst) << 3) |
    ((Fields(lu,ii-inc,jj-inc,kk-inc) >= uconst) << 4) |
    ((Fields(lu,ii-inc,jj-inc,kk)     >= uconst) << 5) |	      
    ((Fields(lu,ii-inc,jj    ,kk)     >= uconst) << 6) |
    ((Fields(lu,ii-inc,jj    ,kk-inc) >= uconst) << 7);

  /* If the index is non-trivial then the contour passes through this
   * cube. Otherwise we are finished. */
  
  if ((index != 0) && (index != 255)) {
    
    /* Calculate the remaining components of any triangle vertices
     * known without interpolation.  We did the X and Y components
     * earlier. */
    
    vertex[U_FIELD][2][Z]  = 
    vertex[U_FIELD][6][Z]  = 
    vertex[U_FIELD][10][Z] = 
    vertex[U_FIELD][12][Z] = pos[Z];
    vertex[U_FIELD][4][Z]  = 
    vertex[U_FIELD][8][Z]  = 
    vertex[U_FIELD][9][Z]  = 
    vertex[U_FIELD][11][Z] = pos[Z] - marching_h;
    
    /* Linearly interpolate along the necessary cube edges to finish up
     * the vertices */
    
    n = 0;
    while ((edge = edge_table[index][n]) != END) {
      vertex[U_FIELD][edge][axis[edge]] =
	Contour_normal_intersect(lu,uconst,edge,normals[edge]);
      n++;
    }
    triangle_list[U_FIELD] = triangle_table[index];
    
    /* All the triangles have been found. Draw them if necessary */
    
    if (do_surface) Draw_triangles (lu,lv,vmin,vmax,vconst);
    
    if (do_filament) {   /* If filament is needed
			  * compute  it, otherwise 
			  * we are finished */
      
      /* Only draw filaments inside the body */
      omit=0;
      for (di=-inc-extra;di<=extra;di++) {
	for (dj=-inc-extra;dj<=extra;dj++) {
	  for (dk=-inc-extra;dk<=extra;dk++) {
	    if (istissue(ii+di,jj+dj,kk+dk) == 0.0) {
	      omit=1;
	      break;
	    }
	  }
	  if (omit) break;
	}
	if (omit) break;
      }
      if (!omit) {
	  /* Calculate index for other lu */
	  other_index =
	    ((Fields(lv,ii    ,jj-inc,kk-inc) >= vconst)     ) |
	    ((Fields(lv,ii    ,jj-inc,kk)     >= vconst) << 1) |
	    ((Fields(lv,ii    ,jj    ,kk)     >= vconst) << 2) |
	    ((Fields(lv,ii    ,jj    ,kk-inc) >= vconst) << 3) |
	    ((Fields(lv,ii-inc,jj-inc,kk-inc) >= vconst) << 4) |
	    ((Fields(lv,ii-inc,jj-inc,kk)     >= vconst) << 5) |
	    ((Fields(lv,ii-inc,jj    ,kk)     >= vconst) << 6) |
	    ((Fields(lv,ii-inc,jj    ,kk-inc) >= vconst) << 7);
	  
	  if ((other_index != 0) && (other_index != 255)) {
	    
	    /* Both u and v contours pass through this cube, so there is
	     * potential for contour intersection (i.e. the filament) */
	    
	    triangle_list[V_FIELD] = triangle_table[other_index];
	    
	    /* Copy over the existing vertices. Each of which only one
	       component may differ (if an intersect exists). */
	    
	    for (n=1; n<=12; n++) {
	      vertex[V_FIELD][n][X] = vertex[U_FIELD][n][X];
	      vertex[V_FIELD][n][Y] = vertex[U_FIELD][n][Y];
	      vertex[V_FIELD][n][Z] = vertex[U_FIELD][n][Z];
	    }
	    
	    /* Do the interpolation */
	    
	    n = 0;
	    while ((edge = edge_table[other_index][n]) != END) {
	      vertex[V_FIELD][edge][axis[edge]] =
		Contour_normal_intersect(lv,vconst,edge,NULL);
	      n++;
	    }
	    
	    /* Now we have all the U and V triangles for this cube so we
	     * can look for the filament. Cube edges that do not contain a
	     * triangle vertex will contain junk values. */
	    
	    /* You may want to try organizing things differently when just
	     * filament is required. At the moment, the Y and Z components
	     * of the vertices are being set too early. You only need set
	     * them before the following call. However, they are only
	     * assignments: the X is ok because it would be unusual not to
	     * get a filament through some part of each Y-Z plane; the Z is
	     * only when the U is non-trivial. */
	    
	    Filament_in_cube (lu,uconst,lv,vconst);
	    
	  } /* if otherindex */
      } /* if !omit */
    } /* if do_filament */
  } /* if index */ 
}
/* ========================================================================= */

static void Filament_in_cube (int lu, Real uconst, int lv, Real vconst) {
  /* At the current cube (ii,jj,kk) both U and V have a non-trivial index.
   * This function finds any triangle intersections (i.e. filament) in this
   * cube.
   *
   * We look at each pair of triangles and find their common line if it
   * exists. The filament thus consists of many small lines.  Experience has
   * shown that usually there are usually only 2 (or maybe 3) triangles in
   * each cube and for this small number of triangles the algorithm should be
   * efficient. Other methods were considered such as following the filament
   * through the cube but then issues such as what do you when there is more
   * than one filament in one cube complicate such a solution. */

  static unsigned int  field;		  /* 0/1 field identifier */
  /* static unsigned int  layer[2];	  /\* where in the input array the fields are *\/ */
  static unsigned int  t_num[2];          /* Number of triangle (0-4) */
  static unsigned int  t_pos[2];          /* Position in triangle list. */
  static CubeEdge      t_cube_edge[2][3]; /* The cube edges of the current U
					   * and V triangle. */
  static GLReal        t_edge_vect[2][5][3][3];
                                          /* All the triangle edge vectors. */
  static GLReal        *te0, *te1, *te;   /* Convenience pointers. */
  static GLReal        plane[2][5][4];    /* Plane coefficients for each
					   * triangle. */
  static GLReal        *u_plane, *v_plane;/* Convenience pointers. */
  static GLReal        p_t0[3], p_t1[3];  /* Vector going from p (the reference
					   * point on the common line) to
					   * the triangle vertex. */
  static GLReal        point[2][3];       /* The line segment to be drawn. */
  static GLReal        den,dc,db,ad;      /* Arithmetic storage. */
  static unsigned int  tri_edge;          /* Loop variable. */
  static GLReal        r,s;               /* Arithmetic storage. */
  static GLReal        p[3], dir[3]; 
  static GLReal        point_r[4];        /* Used to find the
					   * filament. Defines the intersects
					   * of the common plane line with
					   * each triangle edge. */
  static unsigned int  points_found;      /* Intersection points found so far
					   * between the common plane line and
					   * triangle edges. */
  static Axis          dim1,dim2;         /* Dimensions to perform line
					   * intersection in. */
  static Axis          next_axis[3] = {Y,Z,X};
                                          /* Convenient array to cycle axes. */
  static unsigned int  count;             /* How many times you've cycles the
					   * axes. */
  
  /* layer[U_FIELD]=lu; */
  /* layer[V_FIELD]=lv; */

  /* For each U triangle (then for each V triangle) determine the
   * coefficients of the implicit form of the plane through each
   * triangle. That is, find a,b,c,d in a*x + b*y + c*z + d = 0. This is done
   * _once only_ for each triangle. */

  for (field=0;field<=1;field++) { /* for either field */ 

    t_num[U_FIELD] = 0;  /* It doesn't matter in this loop, but use U_FIELD */
    t_pos[U_FIELD] = 0;

    while( (t_cube_edge[U_FIELD][0] = triangle_list[field][t_pos[U_FIELD]]) 
	   != END) {

      /* t0, t1 and t2 are labels for the 3 triangle vertices.  
       * te0, te1, te2 are labels for the vectors along each triangle edge. */

      t_cube_edge[U_FIELD][1] = triangle_list[field][t_pos[U_FIELD]+1];
      t_cube_edge[U_FIELD][2] = triangle_list[field][t_pos[U_FIELD]+2];

      /* Calculate vectors along 2 of the edges of the triangle. Remember them
       * for later. */

      SUB(t_edge_vect[field][t_num[U_FIELD]][0],
	  vertex[field][t_cube_edge[U_FIELD][1]], 
	  vertex[field][t_cube_edge[U_FIELD][0]]);

      SUB(t_edge_vect[field][t_num[U_FIELD]][1],
	  vertex[field][t_cube_edge[U_FIELD][2]], 
	  vertex[field][t_cube_edge[U_FIELD][0]]);

      SUB(t_edge_vect[field][t_num[U_FIELD]][2],
	  vertex[field][t_cube_edge[U_FIELD][2]], 
	  vertex[field][t_cube_edge[U_FIELD][1]]);

      te0 = t_edge_vect[field][t_num[U_FIELD]][0];   /* te0 = t1 - t0 */
      te1 = t_edge_vect[field][t_num[U_FIELD]][2];   /* te1 = t2 - t0 */
                                               /* te2 = t2 - t1  which we may
						* need later */

      plane[field][t_num[U_FIELD]][A] = te0[Y]*te1[Z] - te0[Z]*te1[Y];
      plane[field][t_num[U_FIELD]][B] = te0[Z]*te1[X] - te0[X]*te1[Z];
      plane[field][t_num[U_FIELD]][C] = te0[X]*te1[Y] - te0[Y]*te1[X];    
      plane[field][t_num[U_FIELD]][D] =
	-(vertex[field][t_cube_edge[U_FIELD][1]][X]
                                             *plane[field][t_num[U_FIELD]][A] +
	  vertex[field][t_cube_edge[U_FIELD][1]][Y]
                                             *plane[field][t_num[U_FIELD]][B] +
	  vertex[field][t_cube_edge[U_FIELD][1]][Z]
                                             *plane[field][t_num[U_FIELD]][C]);

      t_num[U_FIELD] += 1;        
      t_pos[U_FIELD] += 3;
    }
  }

  /* Now look at each pair of triangles from the U and V cubes. */

  t_num[U_FIELD] = 0;           /* Triangle number (0-4) */
  t_pos[U_FIELD] = 0;

  while ( (t_cube_edge[U_FIELD][0] = triangle_list[U_FIELD][t_pos[U_FIELD]]) 
	  != END) {

    /* For each triangle in the u cube */

    t_cube_edge[U_FIELD][1] = triangle_list[U_FIELD][t_pos[U_FIELD]+1];
    t_cube_edge[U_FIELD][2] = triangle_list[U_FIELD][t_pos[U_FIELD]+2];

    t_num[V_FIELD] = 0;
    t_pos[V_FIELD] = 0;

    while ( (t_cube_edge[V_FIELD][0] = triangle_list[V_FIELD][t_pos[V_FIELD]]) 
	    != END) {
      /* For each triangle in the v cube */

      t_cube_edge[V_FIELD][1] = triangle_list[V_FIELD][t_pos[V_FIELD]+1];
      t_cube_edge[V_FIELD][2] = triangle_list[V_FIELD][t_pos[V_FIELD]+2];
      
      /* -----------------------------------------------------
       *  Start of code that find the common line of 2 planes. 
       * ----------------------------------------------------- */

      /* Find the common line :   x[] = p[] + t*dir[] */

      u_plane = plane[U_FIELD][t_num[U_FIELD]];
      v_plane = plane[V_FIELD][t_num[V_FIELD]];

      dir[X] = u_plane[B]*v_plane[C] - v_plane[B]*u_plane[C];
      dir[Y] = u_plane[C]*v_plane[A] - v_plane[C]*u_plane[A];
      dir[Z] = u_plane[A]*v_plane[B] - v_plane[A]*u_plane[B];

      den = DOT(dir,dir);

      if (EQUAL_ZERO(den)) {
	/* Planes are parallel so no intersect. 
	 * Overlapping co-planar triangles will be discarded here. */
      } else {

	dc = u_plane[D]*v_plane[C] - u_plane[C]*v_plane[D];
	db = u_plane[D]*v_plane[B] - u_plane[B]*v_plane[D];
	ad = u_plane[A]*v_plane[D] - v_plane[A]*u_plane[D];
	
	p[X] =  (dir[Y]*dc - dir[Z]*db) / den;
	p[Y] = -(dir[X]*dc + dir[Z]*ad) / den;
	p[Z] =  (dir[X]*db + dir[Y]*ad) / den;
	
	/* In fact p is the closest point on the line to the origin. But we
	 * do not use that information here. */
	
	/* --------------------------------------------------------- 
	 * Start of code that finds subset of line in both triangles 
	 * --------------------------------------------------------- */
	
	/* We find where the common line cuts the triangle edges. This will
	 * give us either 0, 2 or 4 points for sure. For the triangles to
	 * intersect, we must have 2 points from the U edges and 2 points
	 * from the V edges. We can stop looking as soon as these conditions
	 * are not met.
	 *
	 * By construction, the common line lies in the same plane as both
	 * triangles. Thus our arithmetic need only be in 2 dimension. We must
	 * be careful in the case where the triangle is normal to an
	 * axis. This will happen rarely under FPA, but is most likely at the
	 * initial condition where scalar values are set by the user.  You
	 * might want to see if there is a better way of handling such
	 * cases. I don't think the method I use here is the best. */

	points_found = 0;

	for (field=0;field<=1;field++) {  /* for either field */ 

	  SUB(p_t0, vertex[field][t_cube_edge[field][0]], p);

	  tri_edge = 0;
	  do /* for first 2 edges */ {

	    te = t_edge_vect[field][t_num[field]][tri_edge];
	    /* "te" <=> "triangle edge" */
				      
	    den = 0.0;
	    dim1 = X; dim2 = Y;
	    count = 0;
	    while (EQUAL_ZERO(den) && count < 3) {
	      dim1 = next_axis[dim1];
	      dim2 = next_axis[dim2];
	      den = te[dim2]*dir[dim1] - te[dim1]*dir[dim2];
	      count ++;
	    }
	    
	    if (EQUAL_ZERO(den)) {
	      /* Common line and triangle edge are parallel. No intersect. */
	      /* This happens quite a lot at the start of the simulation
	       * because scalar values are still close to their initial
	       * values. Holes can be seen. Later on, this doesn't happen
	       * at all. */
	    } else {
	      s = (dir[dim2]*p_t0[dim1] - dir[dim1]*p_t0[dim2]) / den;

	      if ((0.0 <= s) && (s <= 1.0)) {
		/* Intersection is on the triangle edge. If its actually on
		 * a vertex then it could still form the end of a filament
		 * segment (unlikely though). */

		r = (te[dim2]*p_t0[dim1] - te[dim1]*p_t0[dim2]) / den;
		/* This r is used later to give us an ordering on the points
		 * found. */

		point_r[points_found] = r;
		points_found++;
	      }
	    }
	    tri_edge += 1;
	  } while (tri_edge == 1);

	  /* We've done edges 0 and 1. If there have been no points found yet
	   * then the common line cannot pass through this triangle. If we've
	   * found 2 then we need to do no more and can look at the V
	   * triangle.  If we've found 1 then then the other points will be
	   * on the last edge. */

	  if ((points_found == 1) || (points_found == 3)) {
	  
	    /* This whole loop is repeated for the V field and is the reason
	     * this needs to be done for the 3rd edge of the V triangle. */

	    /* We know for sure that we're going to find another point on the
	       3rd edge. */

	    te = t_edge_vect[field][t_num[field]][2];

	    den = 0.0;
	    dim1 = X; dim2 = Y;
	    count = 0;
	    while (EQUAL_ZERO(den) && count < 3) {
	      dim1 = next_axis[dim1];
	      dim2 = next_axis[dim2];
	      den = te[dim2]*dir[dim1] - te[dim1]*dir[dim2];
	      count ++;
	    }

	    if (EQUAL_ZERO(den)) {
	      /* This should never happen. Test anyway. */
	    } else {
	      p_t1[dim1] = vertex[field][t_cube_edge[field][1]][dim1]- p[dim1];
	      p_t1[dim2] = vertex[field][t_cube_edge[field][1]][dim2]- p[dim2];
	      /* We don't need the remaining dimension for the calculation. */
	    
	      s = (dir[dim2]*p_t1[dim1] - dir[dim1]*p_t1[dim2]) / den;
	      if ((0.0 <= s) && (s <= 1.0)) {
		/* This _should_ always happen. Test anyway. */
		r = (te[dim2]*p_t1[dim1] - te[dim1]*p_t1[dim2]) / den;
	    
		point_r[points_found] = r;
		points_found++;
	      }
	    }
	  }

	  /* Found all the points we are going to on the U triangle. Now
	   * repeat for the V triangle as long as we found exactly 2
	   * points. */

	  if (points_found!=2) break;
	}

	if (points_found == 4) {
	  if (Find_two_pts(point, point_r, p, dir)) {
	    
	    /* -----------------------------------------------------
	     * A piece of the filament has been found. Plot or write 
	     * it as necessary.  Write_filament_data() is defined in 
	     * ezscroll.c 
	     * ----------------------------------------------------- */
	    if (show_filament || write_filament)
	      Register_segment(point);
	    /* if(show_filament)  Draw_filament(clipping, point); */
	    /* if(write_filament) Write_filament_data(convert_to_phy*point[0][0], */
	    /* 					   convert_to_phy*point[0][1], */
	    /* 					   convert_to_phy*point[0][2], */
	    /* 					   convert_to_phy*point[1][0], */
	    /* 					   convert_to_phy*point[1][1], */
	    /* 					   convert_to_phy*point[1][2]); */
	  }
	}
      } /* end of dealing with common line */
      
      /* Try next V triangle. */
      t_num[V_FIELD] += 1;
      t_pos[V_FIELD] += 3;
    }
    
    /* Try next U triangle. */
    t_num[U_FIELD] += 1;
    t_pos[U_FIELD] += 3;
  }
}
/* ========================================================================= */

static Bool Find_two_pts (GLReal point[2][3], GLReal point_r[4], GLReal p[3],
			  GLReal dir[3])
{
  /* This function takes the 4 r's in point_r[4] which give the intersections
   * of the common plane line with the triangle edges. It then draws the
   * subset of the common line which lies within both triangles.
   *
   * It is assumed that the r's have been correctly stored in point_r[4]. The
   * first 2 entries will be the U intersections, the 2nd two will be the
   * V. They probably will not be in order. 
   *
   * There must be a quicker way to do this, surely? I've tried Batcher's
   * optimal shuffle but the method below uses less 'ifs' I think because
   * this is a special case. We only need the middle 2 points which should
   * simplify things. */

  static unsigned int u_min, v_min;
  static unsigned int second_position, third_position;
  static unsigned int higher_than_second, also_higher_than_second;

  /* Find order of the U pair */
  if (point_r[1] > point_r[0]) u_min = 0;
  else                         u_min = 1;

  /* Find order of the V pair */
  if (point_r[3] > point_r[2]) v_min = 0;
  else                         v_min = 1;

  /* Find minimum overall */
  if (point_r[v_min+2] > point_r[u_min]) {

    /* Lowest value is the lowest U. The next highest must be the lowest V for
     * there to be a common region. This will happen if the lowest V is lower
     * than the highest U. */

    second_position = v_min+2;
    higher_than_second = (1-u_min);
    also_higher_than_second = (1-v_min)+2;
  } 
  else {

    /* Lowest value is the lowest V. The next highest must be the lowest U for
     * there to be a common region. This will happen if the lowest U is lower
     * than the highest V. */

    second_position = u_min;
    higher_than_second = (1-v_min)+2;
    also_higher_than_second = (1-u_min);
  }

  if (point_r[second_position] < point_r[higher_than_second]) {

    /* There is a line but we don't know which is the third position. */

    if (point_r[higher_than_second] < point_r[also_higher_than_second]) {
      third_position = higher_than_second;
    }
    else {
      third_position = also_higher_than_second;
    }

    /* set the points */

    POINT_ALONG_LINE(point[0], p, point_r[second_position], dir);
    POINT_ALONG_LINE(point[1], p, point_r[third_position], dir);
    return TRUE;
  }
  else return FALSE;
}
/* ========================================================================= */

/* Given a cube edge, relative_edge_pos tells you how to get from (ii,jj,kk)
 * to the end of the edge which is furthest along the edge's axis. The entry
 * for edge 1 tells you that you need to move down the Y axis from (ii,jj,kk)
 * and arrive at (ii,jj-1,kk). It also tells you that you do not need to move
 * along either the X or the Z axis. This information is used by
 * Contour_normal_intersect() which calculates the intersection of the
 * iso-surface with any given cube edge. The fact that the cube vertex "is
 * further along the edges axis" is important because then you know that the
 * intersect always lies behind you. This is why there is always at least one
 * '0' in each entry in the table.
 *
 * Note that in fact the 1's are replaced by "inc" in Set_relative_edge_pos()
 * This is because the graphics resolution is variable so you might want to
 * move along an axis by more than one numerical cube length. Doing this
 * saves some multiplications in Contour_normal_intersect(). */

static unsigned int relative_edge_pos[13][3] = {
  {0,0,0}, {0,1,0}, {0,0,0}, {0,0,0}, {0,0,1}, {1,1,0},
  {1,0,0}, {1,0,0}, {1,0,1}, {0,1,1}, {0,1,0}, {0,0,1}, {0,0,0} };

static void Set_relative_edge_pos (int inc)
{
  int p, q;
  for (p=1; p<=12; p++) {
    for (q=0; q<=2; q++) {
      if (relative_edge_pos[p][q] != 0) relative_edge_pos[p][q] = inc;
    }
  }
}
/* ========================================================================= */

static GLReal Contour_normal_intersect (int layer, Real contour, CubeEdge edge, 
					GLReal *normal) 
{
  /* This function returns the position of the intersection of a contour with
   * the cube edge specified. It is assumed that the edge specified contains
   * a contour otherwise a divide by zero may occur. You can't go wrong as
   * long as you use the cube index to point to the edge table which will
   * tell you which edges have an intersect.
   *
   * The other field components at the intersect can be determined by the
   * calling routine because they are the same as the position of the cube
   * edge.
   *
   * May 2007, added computation of normals if normal is not NULL.  Normals
   * are found from the field gradient (which is normal to the field contour).
   * Gradients are computed by finite differences on the computational grid at
   * the two cube vertices on the current edge.  Then the same linear
   * interpolation used to find the contour intersect (triangle vextex) is
   * used to interpolate the gradient to the triangle vertex.  
   *
   */

  static unsigned int  begin [3],
                       end   [3];
  static GLReal        ratio, norm;
  int k;

  /* Set end to be the position of the node in the numerical volume which is
   * furthest along the axis on the specified edge specified. See declaration
   * of relative_edge_pos. See Marching_cubes(). */

  end[X] = ii-relative_edge_pos[edge][X];
  end[Y] = jj-relative_edge_pos[edge][Y];
  end[Z] = kk-relative_edge_pos[edge][Z];

  /* The other end of the edge differs only along its axis by inc. */

  begin[X] = end[X];
  begin[Y] = end[Y];
  begin[Z] = end[Z];
  begin[axis[edge]] -= inc;

  /* Calculate the ratio that the intersect occurs along the cube edge from
   * the end. */

  ratio = (contour-Fields(layer,end[X],end[Y],end[Z]))
    / ( Fields(layer,begin[X],begin[Y],begin[Z])
       -Fields(layer,end[X],end[Y],end[Z]) );

  /* For the contour intersection (triangle vertex), all that remains is the
   * return statement at the end.
   *
   * If we are to compute normal also.  Use finite differences to compute
   * gradients at relevant cube vertices and interpolate to find the gradient
   * at triangle vertex. */

  if (normal != NULL) {

    normal[0] = 
      (  Fields(layer,begin[X]+1,begin[Y],begin[Z]) 
	 - Fields(layer,begin[X]-1,begin[Y],begin[Z]) ) * ratio
      + 
      (  Fields(layer,end[X]+1,end[Y],end[Z]) 
	 - Fields(layer,end[X]-1,end[Y],end[Z]) ) * (1. - ratio);

    normal[1] = 
      (  Fields(layer,begin[X],begin[Y]+1,begin[Z]) 
	 - Fields(layer,begin[X],begin[Y]-1,begin[Z]) ) * ratio
      + 
      (  Fields(layer,end[X],end[Y]+1,end[Z]) 
	 - Fields(layer,end[X],end[Y]-1,end[Z]) ) * (1. - ratio);

    normal[2] = 
      (  Fields(layer,begin[X],begin[Y],begin[Z]+1) 
	 - Fields(layer,begin[X],begin[Y],begin[Z]-1) ) * ratio
      + 
      (  Fields(layer,end[X],end[Y],end[Z]+1) 
	 - Fields(layer,end[X],end[Y],end[Z]-1) ) * (1. - ratio);

    /* Normalize.  The minus sign is because we want the normal in the
       direction of minus the gradient */

    norm = -sqrt(normal[0]*normal[0]+normal[1]*normal[1]+normal[2]*normal[2]);
    for(k=0;k<3;k++) normal[k] /= norm;
  }

  /* Now return the contour intersection (which gives the non-trivial
     coordinate of the current triangle vertex. */
  return (pos[axis[edge]] - marching_h*ratio);
}
/* ========================================================================= */

static void Set_draw_mode_off (void) {
  if (draw_mode==OFF) {
    printf("off again? this shouldn't be!\n");
  }
  glEnd();
  if (verbose>=3) glFlush();
  draw_mode=OFF;
}
/* ========================================================================= */

static void Set_draw_mode_lines (int clipping, GLReal lwidth) {
  static GLReal last_lwidth=0;
  if(draw_mode==LINES && lwidth==last_lwidth) return;

  if(draw_mode!=OFF) {
    glEnd();
    if (verbose>=4) glFlush();
  }
  if(clipping) glDisable(GL_CLIP_PLANE0);  /* we never clip lines */
  glDisable(GL_LIGHTING);                  /* we don't shine light on lines */
  glLineWidth(lwidth);
  glBegin(GL_LINES);
  draw_mode=LINES;
  last_lwidth=lwidth;
}
/* ========================================================================= */

static void Set_draw_mode_curves (int clipping, GLReal lwidth) {
  /* if(draw_mode==CURVES) return; - continuous chains do not concatenate */

  if(draw_mode!=OFF) {
    glEnd();
    if (verbose>=4) glFlush();
  }
  if(clipping) glDisable(GL_CLIP_PLANE0);  /* we never clip lines */
  glDisable(GL_LIGHTING);                  /* we don't shine light on lines */
  glLineWidth(lwidth);
  glBegin(GL_LINE_STRIP);
  draw_mode=CURVES;
}
/* ========================================================================= */

static void Set_draw_mode_triangles (int clipping) {
  if(draw_mode==TRIANGLES) return;

  if(draw_mode!=OFF) {
    glEnd();
    if (verbose>=4) glFlush();
  }

  if(clipping)
    glEnable(GL_CLIP_PLANE0); 
  else
    glDisable(GL_CLIP_PLANE0);
  glEnable(GL_LIGHTING);
  glBegin(GL_TRIANGLES);
  draw_mode=TRIANGLES;
}
/* ========================================================================= */

static void Set_draw_mode_fan (int clipping) {
  /* if(draw_mode==FAN) return; - fans do not concatenate */

  if(draw_mode!=OFF) {
    glEnd();
    if (verbose>=4) glFlush();
  }

  if(clipping)
    glEnable(GL_CLIP_PLANE0); 
  else
    glDisable(GL_CLIP_PLANE0);
  glEnable(GL_LIGHTING);
  glBegin(GL_TRIANGLE_FAN);
  draw_mode=FAN;
}
/* ========================================================================= */

static void Set_draw_mode_strip (int clipping) {
  /* if(draw_mode==STRIP) return; - strips do not concatenate */

  if(draw_mode!=OFF) {
    glEnd();
    if (verbose>=4) glFlush();
  }

  if(clipping)
    glEnable(GL_CLIP_PLANE0); 
  else
    glDisable(GL_CLIP_PLANE0);
  glEnable(GL_LIGHTING);
  glBegin(GL_QUAD_STRIP);
  draw_mode=STRIP;
}
/* ========================================================================= */


/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */

/* ------------------------------------------------------------------------- 
 *     Here starts the initialization part of the code in which the lookup
 *                           tables are generated. 
 *		     
 * ------------------------------------------------------------------------- */

/* The main lookup table is the marching cubes lookup table called triangle
 * table. Each of the 8 vertices of a marching cube are assigned either a 0
 * or 1 depending on whether they are above or below the contour value. Given
 * this marching cubes index, it holds the instructions on how to draw the
 * contour through cube using at most 5 triangles.
 * 
 * There are 21 topologically distinct ways you can triangulate a cube. These
 * are listed below together with the index to which they correspond. By
 * rotating such cubes through all 24 orientations we can generate all the
 * entries in the lookup table.
 *
 * For indexes with 4 vertices high and 4 vertices low, rotating the cube
 * will eventually generate the entry for the complement of the original
 * index.  The triangle list so generated could well be topologically
 * different to the original triangle list. The 1987 paper used topologically
 * identical triangulations for complimentary cases. This has since found to
 * produce 'holes' in certain cases and so Montani, Scateni and Scopigno
 * (1994) devised 6 modified triangulation for complimentary cases. 3 of
 * these have 4 vertices high and 4 low and fortunately these are precisely
 * the cases which are topologically different when rotated to their
 * complimentary index.  The other 3 are new triangulations but do not have 4
 * vertices high and 4 vertices low so rotating these does not cause any
 * problems.
 * ------------------------------------------------------------------------- */


static CubeEdge table_generators[NUM_GENERATORS][MAX_TRIANGLE_LIST_LENGTH+1] =

/* The "+1" is for the first element - the index of the generator which is
 * used later to build the whole table. */

{

/* Unambiguous cases which have less than 4 vertices high. Rotating one of
 * these does not generate the complimentary case so we list them
 * explicitly. */

  {1,  1,4,9,END},                /*  case 1  */
  {254,1,4,9,END},                /*  case 1 compliment  */
  {3,  10,9,2,9,2,4,END},         /*  case 2  */
  {252,10,9,2,9,2,4,END},         /*  case 2 compliment  */
  {65, 1,4,9,7,12,6,END},         /*  case 4  */
  {190,1,4,9,7,12,6,END},         /*  case 4 compliment  */
  {50, 6,8,2,8,2,9,2,9,1,END},    /*  case 5  */
  {205,6,8,2,8,2,9,2,9,1,END},    /*  case 5 compliment  */

/* Unambiguous cases which have exactly 4 vertices high. The compliments will
 * be generated by the rotations. Note that the exact of order of the
 * triangle vertices for the complement will not be the same (because we
 * obtain them by rotational symmetry not complimentary symmetry) but the
 * triangle edges on each face are the same. */

  {51, 2,4,6,4,6,8,END},                 /*  case 8  */
  {78, 11,4,7,4,7,1,7,1,6,1,6,10,END},   /*  case 9  */
  {113,7,8,12,8,12,1,12,1,10,8,1,4,END}, /*  case 11 */
  {77, 2,1,6,1,6,11,6,11,7,1,11,9,END},  /*  case 14 */

/* Ambiguous cases with less than 4 vertices high and have different
 * compliments according to "A modified look-up table for implicit
 * disambiguation of Marching Cubes" by Montani, Scateni, Scopigno; Visual
 * Computer 1994 (10).  */

  {5,  1,4,9,3,2,12,END},                       /*  case 3   */
  {250,4,9,3,9,3,12,12,9,2,9,2,1,END},          /*  case 3 compliment  */
  {67, 10,9,2,9,2,4,7,12,6,END},                /*  case 6   */
  {188,10,9,6,9,6,4,6,4,7,4,7,12,12,4,2,END},   /*  case 6 compliment  */
  {74, 1,10,2,4,3,11,7,12,6,END},               /*  case 7   */
  {181,11,4,7,4,7,1,7,1,6,1,6,10,3,2,12,END},   /*  case 7 compliment  */

/* Ambiguous cases with exactly 4 vertices high. Compliments will be
 * generated by rotation which agree with the 1994 paper. And it is important
 * in these cases that the inverse of the index is topologically different.
 * */

  {105,11,9,3,9,3,1,7,5,12,5,12,10,END},        /*  case 10  */
  {58, 6,8,2,8,2,9,2,9,1,11,3,4,END},           /*  case 12  */
  {90, 4,1,9,11,7,8,2,3,12,5,6,10,END},         /*  case 13  */
};

/* Side note
 *
 * We have experimented using GL_TRIANGLE_STRIP in order to simplify the list
 * of triangles and reduce the number of vertices needed to pass to OpenGL
 * (and thus reduce the number of transformations required). However, in
 * order to do this, you need more glBegin and glEnds in order to keep
 * changing primitives. We believe that it is easier all round to provide
 * OpenGL with just GL_TRIANGLES. It is also very convenient because it also
 * makes finding surface intersection easier; everything is a triangle!  */

/* ------------------------------------------------------------------------- */

/* To generate the look up table, we simply rotate each of the above
 * generators through all 24 orientations. Under a rotation about the X axis,
 * x_mod_edge tells you where each edge is mapped. x_mod_vertex tells you
 * where each cube vertex is mapped. Similarly for a rotation about the Y
 * axis. */

static CubeEdge   x_mod_edge[13]  = {0,3,12,7,11,1,10,5,9,4,2,8,6};
static CubeVertex x_mod_vertex[9] = {0,8,4,64,128,1,2,32,16};

static CubeEdge   y_mod_edge[13]  = {0,9,4,11,8,10,2,12,6,5,1,7,3};
static CubeVertex y_mod_vertex[9] = {0,16,1,8,128,32,2,4,64}; 

/* ------------------------------------------------------------------------- */

void Marching_ini (void)
{
  CubeIndex  index;
  int        gen;    

  /*  Initialize the triangle table to be empty  */
  for (index=0; index<=255; index++) {
    triangle_table[index][0] = END;
  }

  /* Copy all the basic 14 recipes into the triangle table and do all 24
   * orientations for each one. This is extremely inefficient. However, the
   * code is concise and easier to debug. Most entries are generated in more
   * than one way (and an error is generated if any inconsistencies
   * arise). Thus we can be confident our table is correct. This is only done
   * once, so efficiency is not an issue. */

  for (gen=0; gen<NUM_GENERATORS; gen++) {
    index = table_generators[gen][0];
    strcpy((char *)triangle_table[index], (char *)table_generators[gen]+1);
    Do_all_orientations(table_generators[gen][0]);
  }

  /* Generate the edge table from the triangle table by deleting all the
   * repeated edges. */

  Generate_edge_table();
  
  /*  Display the triangle table  */
  if(0) {
    printf ("Triangle table and corresponding edge table:\n");
    printf ("--------------------------------------------\n");
    for (index=0; index<=255; index++) { 
      printf ("\ntriangle_table[%3d] = ",index); 
      Print_list(triangle_table[index]);
      printf ("\n    edge_table[%3d] = ",index);
      Print_list(edge_table[index]);
    }
    printf ("\n"); 
  }
  /* I have checked the generated table against Lorensen's table which he
   * includes in the Visualization Toolkit Version 1.0. Randomly comparing
   * both tables and specifically looking at 'awkward' cases confirms that
   * they are essentially the same. He uses a different labeling scheme and
   * makes different topologically arbitrary choices to his own paper. He
   * uses a similar modification to the case table to deal with holes. I
   * follow the labeling scheme in his paper and the modifications suggested
   * by Montani et al.  */
}
/* ========================================================================= */

static CubeIndex Rotate_edge_list (CubeIndex index, int direction)
{
  /* This takes an entry in the triangle_table and generates the new list of
   * triangles obtained by rotating the cube around either the X or the Y
   * axis. */

  CubeEdge    *mod_edge;
  CubeVertex  *mod_vertex;
  CubeIndex    new_index = 0;
  CubeEdge     new_edge_list[MAX_TRIANGLE_LIST_LENGTH];
  int          i;

  if (direction == 'x') {
    mod_edge   = x_mod_edge;
    mod_vertex = x_mod_vertex;
  }
  else {
    mod_edge   = y_mod_edge;
    mod_vertex = y_mod_vertex;
  }

  for (i=0; i<=7; i++) {
    if (index & (1<<i)) new_index |= mod_vertex[i+1];
  }

  i = 0;
  while (triangle_table[index][i] != END) {
    new_edge_list[i] = mod_edge[triangle_table[index][i]];
    i++;
  }
  new_edge_list[i] = END;

  if (triangle_table[new_index][0] == END) {
    /*  The first time this entry has been defined  */
    strcpy((char *)triangle_table[new_index], (char *)new_edge_list);
  }

  else {
    if (strcspn ((char *)triangle_table[new_index], (char *)new_edge_list) 
	!= 0) {
      /* Triangle lists are considered equivalent if they have the same
       * elements (even if they are in a different order).  I know this is a
       * weak test but its better than nothing. */
      fprintf (stderr,"Logic error generating lookup table!\n");
    }
  }

  return (new_index);
}
/* ========================================================================= */

static CubeIndex Rotate_edge_list_x (CubeIndex index)
{
  return (Rotate_edge_list(index,'x'));
}
/* ========================================================================= */

static CubeIndex Rotate_edge_list_y (CubeIndex index)
{
  return (Rotate_edge_list(index,'y'));
}
/* ========================================================================= */

static void Rotate_diagonal (CubeIndex index)
{
  CubeIndex  lindex = index;
  int        i;

  for (i=0; i<=2; i++) lindex = Rotate_edge_list_x(Rotate_edge_list_y(lindex));
  if (lindex != index)
    fprintf(stderr,"Assertion failed in Rotate_diagonal\n");
}
/* ========================================================================= */

static void Do_all_orientations (CubeIndex index)
{
  /* Given an entry in the triangle_table at location index, this function
   * rotates the cube through all 24 orientations and writes the resulting
   * edge lists to the edge table. */

  CubeIndex  lindex = index;   /* local copy of index */
  int        i;

  for (i=0; i<=3; i++) {
    Rotate_diagonal(lindex);
    lindex = Rotate_edge_list_x(lindex);
  }
  if (lindex != index)
    fprintf(stderr,"Assertion 1 failed in Do_all_orientations\n");
  
  lindex = Rotate_edge_list_y(Rotate_edge_list_y(lindex));
  for (i=0; i<=3; i++) {
    Rotate_diagonal(lindex);
    lindex = Rotate_edge_list_x(lindex);
  }
  lindex = Rotate_edge_list_y(Rotate_edge_list_y(lindex));
  if (lindex != index)
    fprintf(stderr,"Assertion 2 failed in Do_all_orientations\n");
}
/* ========================================================================= */

static void Generate_edge_table (void)
{
  /* This takes the triangle table and generates the edge_table by deleting
   * all the repeated vertices. */

  CubeIndex  index;
  int        pos1, pos2;
  Bool       got_already;
  CubeEdge   new_edge;

  for (index = 0; index<=255; index++) {
    
    /* go through this entry and write any new edges to the edge table */
    pos1 = 0;
    edge_table[index][0] = END;

    while ((new_edge = triangle_table[index][pos1]) != END) {

      pos2 = 0;
      got_already = FALSE;

      while (edge_table[index][pos2] != END) {
	if (new_edge == edge_table[index][pos2]) got_already = TRUE;
	pos2++;
      }

      if (!got_already) {
	edge_table[index][pos2] = new_edge;
	edge_table[index][pos2+1] = END;
      }

      pos1++;
    }
  }
}
/* ========================================================================= */

static void Print_list (CubeEdge *p)
{
  /* Simple routine which prints a list of edges as stored in the triangle
   * table and the edge table. */

  if (*p == END) return;                       /* Empty list */
  while (*(p+1) != END) printf ("%d, ",*p++);  /* Print all but the last */
  printf ("%d",*p);                            /* Print the last */
}
/* ========================================================================= */
