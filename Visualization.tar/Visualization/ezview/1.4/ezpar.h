/* This is part of EZView: copyright 2012, Vadim Biktashev vnb@liv.ac.uk */

_(m,int,-1)		/* current frame number: instead of istep */
_(mmin,int,0)	   	/* min admissible frame number */
_(mmax,int,0)		/* max admissible frame number */
_(mstep,int,0)		/* admissible frame number step */
_(imin,int,1)		/* 3D */
_(imax,int,-1)		/*   subset*/
_(jmin,int,1)		/*   of */
_(jmax,int,-1)		/*   the box */
_(kmin,int,1)		/*   to be */
_(kmax,int,-1)		/*   displayed */

_(norm_res,int,1)	/* view and run mode resolution */
_(rot_res,int,1)	/* rotate mode resolution */

_(show_surface,int,1)	/* whether to draw the surface */
_(ulayer,int,0)		/* activator channel in input files */
_(uc,Real,0)		/* activator critical value */
_(vlayer,int,0)		/* inhibitor channel in input files */
_(vmin,Real,0)		/* inhibitor range lower end */
_(vmax,Real,0)		/* inhibitor range upper end */
_(wlayer,int,0)		/* inhibitor channel in input files */
_(wmin,Real,0)		/* inhibitor range lower end */
_(wmax,Real,0)		/* inhibitor range upper end */
_(color_mode,int,0)	/* surface colouring algorithm */
_(alphamin,Real,0)	/* minimal opaqueness */
_(alphamax,Real,0)	/* maximal opaqueness */

_(show_filament,int,0)	/* whether to draw filaments */
_(layer1,int,0)		/* sing layer 1 */
_(const1,Real,0)	/* sing const 1 */
_(layer2,int,0)		/* sing layer 2 */
_(const2,Real,0)	/* sing const 2 */
_(flm_r,Real,1)	        /* filament          */
_(flm_g,Real,1)         /*    colour         */
_(flm_b,Real,0.8)       /*    components     */
_(flm_wt,Real,3.0)      /*    and the linewidth */
_(flm_balls,int,0)      /* "", plot it by spheres once=1 or twice=2 */

_(theta,Real,0)		/* view angle: rotation about z axis */
_(phi,Real,0)		/* view angle: elevation about z=0 plane */
_(psi,Real,0)		/* view angle: rotation around view line */
_(distance,Real,5.0)	/* former DISTANCE of ezgraph3d.h */
_(theta0,Real,0)	/* initial */
_(phi0,Real,0)		/*    values */
_(psi0,Real,0)		/*    of the same */
_(distance0,Real,5.0)	/* former DISTANCE of ezgraph3d.h */

_(remove_backs,int,0)	/* do not show backs of waves */
_(clipping,int,0)	/* whether to use clipping plane */

_(write_images,int,0)	/* whether to save the images */
_(write_filament,int,0)	/* whether to write filament data */
_(write_history,int,0)	/* whether to write to history file */
_(hist_x,int,0)		/* coordinates       */
_(hist_y,int,0)		/*    of the history */
_(hist_z,int,0)		/*    points         */

_(bg_r,Real,0.4)        /* background        */
_(bg_g,Real,0.4)        /*    colour         */
_(bg_b,Real,1.0)        /*    components     */
_(bbox_r,Real,0.0)      /* bounding box      */
_(bbox_g,Real,0.0)      /*    colour         */
_(bbox_b,Real,0.0)      /*    components,    */
_(bbox_a,Real,0.5)      /*    its transparency */
_(bbox_wt,Real,2.0)     /*    and the linewidth */
_(grid_h,Real,0)	/* dimensional grid step */
_(dt,Real,0)		/* dimensional time step */

_(verbose,int,1)	/* verbosity level */
_(lightx,Real,50.0)	/* position  */
_(lighty,Real,-10.0)	/*   of */
_(lightz,Real,-10.0)	/*   the */
_(lightw,Real,0.0)	/*   light */

#if TRACE
_(tracezfix,int,-1)     /* negative means use given value */
_(tracelen,int,0)
_(traceint,int,1)
_(trl_r,Real,0.8)       /* LAST filament        */
_(trl_g,Real,0.8)       /*    colour            */
_(trl_b,Real,1.0)       /*    components        */
_(trl_a,Real,1.0)       /*    opaqueness        */
_(trl_wt,Real,1.0)      /*    the linewidth     */
_(trl_dx,Real,0.0)	/* displacement		*/
_(trl_dy,Real,0.0)	/*   for visualization	*/
_(trl_dz,Real,0.0)	/* 	in grid steps. 	*/
_(trf_r,Real,0.8)       /* FIRST filament       */
_(trf_g,Real,0.8)       /*    colour            */
_(trf_b,Real,1.0)       /*    components        */
_(trf_a,Real,1.0)       /*    opaqueness        */
_(trf_wt,Real,1.0)      /*    and the linewidth */
_(trf_dx,Real,0.0)	/* displacement		*/
_(trf_dy,Real,0.0)	/*   for visualization	*/
_(trf_dz,Real,0.0)	/* 	in grid steps. 	*/
#endif
#if MARKER
_(marker_size,Real,1)	  /* size and             */
_(marker_x,Real,0)	  /*    coordinates       */
_(marker_y,Real,0)	  /*    of the marker     */
_(marker_z,Real,0)	  /*    position          */
_(marker_r,Real,1.0)      /* marker               */
_(marker_g,Real,1.0)      /*    colour            */
_(marker_b,Real,0.0)      /*    components,       */
_(marker_a,Real,0.5)      /*    its transparency  */
_(marker_wt,Real,2.0)     /*    and the linewidth */
#endif
#if TABOO
_(taboo_byte,int,-1)     /* such byte in ppm input should not be used */
#endif
