/* ------------------------------------------------------------------------- *
 * ezscroll.h -- header file for EZ-Scroll
 *
 * Copyright (C) 1996 - 1998, 2006, 2007 Dwight Barkley and Matthew Dowle
 * ------------------------------------------------------------------------- */

/* Modifications for EZView: 2010-2012, Vadim Biktashev vnb@liv.ac.uk        */

#ifndef _EZSCROLL_
#define _EZSCROLL_

/* ------------------------------------------------------------------------- */
/* These are the main parameters affecting the compilation of EZ-Scroll.     */
/* Define them according to your needs.                                      */
/*                                                                           */
typedef double  Real;      /* precision of Real variables (float or double)  */
#define FFMT "%lg"         /* default format for reading/writing it          */
                          /*                                                 */
#define GRAPHICS   1      /* if 1 then run with interactive graphics         */

/* ------------------------------------------------------------------------- */
/* Special things - you probably will not need any of these                  */
#define TRACE      1      /* if 1 then draw trace of z-section of filament   */
#define FLMCOLL    1      /* if 1 then collect filament segment into a line  */
#define MARKER     1      /* if 1 then display a marker with specified coords */
#define TABOO	   1      /* if 1 then a "no-value" in fields is allowed     */
#define READFLM	   1      /* if 1 then filament are read, not calculated     */
/* ------------------------------------------------------------------------- */

/* 
 * I always define min, max, and make sure M_PI is defined 
 * ------------------------------------------------------- */
#define min(a,b)      ((a)>(b) ? (b) : (a))   
#define max(a,b)      ((a)>(b) ? (a) : (b))   
#ifndef M_PI
#define M_PI	      3.14159265358979323846
#endif

/* --------------------------------------------------- 
 * Global variables used throughout the EZ-Scroll Code 
 * (I use lots of them)
 * --------------------------------------------------- */

extern char *fmt, *template;		/* data files description */
extern Real *fields, *u, *v;		/* arrays for concentration fields */

/* run time changeable parameters: */
#define _(n,t,i) extern t n;
#include "ezpar.h"
#undef _(n,t,i)

extern int nx, ny, nz;			/* # of grid points per direction */
extern int nl, nlread;                  /* maximal and actual (read) number of layers */
extern int field_size;			/* array size for each field */
extern Real plot_length[3];   /* Lengths of the displayed volume in graphics
			       * coordinates (see Draw_ini()). */
extern Real plot_ini[3];      /* Shift of this volume wrt simulation volume
			       * in the same coords */

#if TABOO
extern Real taboo;
#endif

#if READFLM
extern char *flmtemplate;
#endif

/* -------------------------------------------------------------------------
 * All index ranges throughout the code are expressed in terms of NX, NY,
 * and NZ.  The code is generally more efficient if these are known numbers
 * at compile time, but then one must recompile for each change.  If the
 * values are known (eg specified on the compile line) then do nothing
 * here, otherwise define NX etc to be the *variables* nx, etc.
 * ------------------------------------------------------------------------- */

#ifndef NX
  #define NX  nx
#endif

#ifndef NY
  #define NY  ny
#endif

#ifndef NZ
  #define NZ  nz
#endif

/* ------------------------------------------------------------------------- 
 * Memory for the chemical fields (u and v) 
 * is allocated in Allocate_memory() in ezscroll.c.  These are      
 * allocated as long (single dimensional) arrays.  Here macros are defined   
 * so that one can easily reference a value corresponding to a particular    
 * grid point, i.e. macros are defined to treat all arrays as                
 * multi-dimensional. If you don't like the way I do this, you should be     
 * able to change it easily by making modifications here and in              
 * AllocateMem().  Let me know if you find a significant improvement.        
 *                                                                           
 * INDEX(i,j,k) converts grid point (i,j,k) to the array index.              
 *                                                                           
 * U(i,j,k)          --  u field at grid point (i,j,k)                       
 * V(i,j,k)          --  v field at grid point (i,j,k)                       
 * Sigma_u(s,i,j,k)  --  Spatial-sum array for u: s=0 or 1 (see ezstep3d.c)    
 * Sigma_v(s,i,j,k)  --  Spatial-sum array for v: s=0 or 1 (see ezstep.c)    
 * Fields (f,i,j,k)  --  array of fields: f=0 for u or f=1 for v.            
 *                       (it is necessary to have one array containing both  
 *                        u and v for the graphics routines in ezmarching)   
 * ------------------------------------------------------------------------- */

#define K_INC      ((NX+2)*(NY+2))  
#define J_INC       (NX+2)
#define I_INC        1
#define FIELD_SIZE ((NZ+2)*(NY+2)*(NX+2)) 
#define INDEX(i,j,k)  ((i)*I_INC + (j)*J_INC + (k)*K_INC)

#define Fields(f,i,j,k)   fields [(f)*FIELD_SIZE + INDEX(i,j,k)]


/* ------------------------------------------- 
 * Prototypes for public functions defined in: 
 * ------------------------------------------- */

/* ezscroll.c 
 * ---------- */
void Write_filament_point (float x, float y, float z); 
void Write_filament_segment (void); 
void Write_filament_frame (void); 
void Write_history   (int wrt_step);
void Write_fc        (char *template);
int  Read_fmt (char *fmt,char *template,int m);

void play (char *soundfilename);

/* ezgraph3d.c 
 * ----------- */
void  Draw         (void);
void  Draw_title   (void);
void  Draw_ini     (void);
int   Event_check  (void);
void  Pause        (void);
void  QuitX        (void);

/* ezmarching.c 
 * ------------ */
void  Marching_cubes  (unsigned int resolution);
void  Marching_ini    (void);

#endif /*  _EZSCROLL_  */
