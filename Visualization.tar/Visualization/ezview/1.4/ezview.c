/* ------------------------------------------------------------------------- */
/* EZ-SCROLL: A Code for Simulating Scroll Waves Version 1.5                 */
/* Copyright (C) 1996 - 1998, 2006, 2007 Dwight Barkley and Matthew Dowle    */
/* D.Barkley@warwick.ac.uk                                                   */
/*                                                                           */
/* EZView: 2010-2012, Vadim Biktashev vnb@liv.ac.uk                          */
/* ------------------------------------------------------------------------- */
/* EZTrace: also plot at trace of filament/tip at selected z level           */
/* ------------------------------------------------------------------------- */

#include <assert.h>
/* #include <curses.h> */
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tiffio.h>
#include <time.h>
#include <unistd.h>
#include "ezscroll.h"


/* todo: make this into globally used macro? */
#define error(...) {fprintf(stderr,__VA_ARGS__); return 0;}


/* todo: make some sound? */
void beep(void) {;}

/* 
 * Global variables used throughout the EZ-Scroll Code (see ezscroll.h)
 * -------------------------------------------------------------------- */

Real *fields, *u, *v;
int   nx, ny, nz, nl, nlread, field_size; 
Real plot_length[3];
Real plot_ini[3];
#if TABOO
Real taboo=NAN;
#endif
#if READFLM
char *flmtemplate=NULL;
#endif
char *fmt, *template;

#define _(n,t,i) t n=i;
#include "ezpar.h"
#undef _(n,t,i)


/* Global variables for this file only
 * ----------------------------------- */

static  FILE *history_file, *filament_file; 

/* Private functions 
 * ----------------- */

static int Initialize      (char *task);
static void  Allocate_memory (void);
static int   Read_ez         (char *template,int m);
static int   Read_tiffsplit  (char *template,int m);
static int   Read_tiff       (char *template,int m);
static int   Read_ppm        (char *template,int m);
static int   Read_dmp        (char *template,int m,int intypesize);
static int   Read_bbg        (char *template,int m);
/* static void  Write_history   (int m); */
#if TRACE
static char *sgzfile;
static long  Read_trace	     (char *sgzfile, int tracezfix);
#endif
static void  Finish_up       (void);

#define NEXT_LINE(fp) while(!feof(fp) && getc(fp)!='\n');  /* macro used to skip to end 
	  							 of input line */

/* ========================================================================= */

int main(int argc, char **argv) {
  char *ptr, *argv0, *task; 

  /* Check args if any and define the task file names */
  argv0 = (ptr=strrchr(argv[0],'/'))?(ptr+1):(argv[0]);
  if ( ((argc>1) &&  (0!=strchr(argv[1],'?')))
       || ((argc>1) && (0==strncmp(argv[1],"-h",2)))
       || ((argc>1) && (0==strncmp(argv[1],"--h",3)))
       || (argc>2)
       ) { 
    fprintf(stderr,"Usage: %s [task_file (task.dat)]\n",argv[0]);
    exit(1);
  }
  task	= (argc>1) ? argv[1] : "task.dat";
  
  if (0==Initialize(task)) return -1;

  /* The main loop, modelled on the simulation loop of EZSCROLL */
  /* NB m, mmin, mmax, mstep all can be changed in dialogue     */
  /* Uncomment the version you prefer */
  /* #define ENDRANGE mstep *= -1; write_history=write_filament=save_images=0 */
  /* #define ENDRANGE mstep *= -1; Pause() */
  #define ENDRANGE Pause()
  for (m=mmin;;m+=mstep) {
    if (verbose) printf("m=%d\n",m);
    if (m>mmax) {m=mmax; ENDRANGE; }
    if (m<mmin) {m=mmin; ENDRANGE; }
    if (0==Read_fmt(fmt,template,m) || mstep==0) {
      beep();
      if (mstep>0) {mmax=m-mstep; m=mmax;}
      if (mstep<0) {mmin=m-mstep; m=mmin;}
      ENDRANGE;
    };
    Draw();
    if (write_history) Write_history(m);
    if (0!=Event_check()) break;
  }

  Finish_up();
  return 0;
}
/* ========================================================================= */

int Initialize (char *task) {
  /* Read task file, open output files, and initialize graphics and time
   * stepping.  */

  FILE *fp;
  #define BUFLEN 4096
  char buf[BUFLEN], *p;
  int i;

  /* signal to Write_filament_data we haven't really started yet */
  m=-1;

  /* ---------------------------------- 
   * Read parameters from the task file
   * ---------------------------------- */

  if((fp=fopen(task,"r"))==NULL) {
    fprintf(stderr,"Cannot open task file %s\n",task);
    exit(1);
  }
#define FGETS if(!feof(fp)) fgets
#define FSCANF if (!feof(fp)) fscanf
#define F FFMT

  FGETS(buf,BUFLEN,fp);p=strtok(buf," \t\r\b\n"); fmt=strdup(p);
  FGETS(buf,BUFLEN,fp);p=strtok(buf," \t\r\b\n"); template=strdup(p);
  FSCANF(fp,"%d,%d,%d",		&mmin,&mstep,&mmax);		NEXT_LINE(fp);
  FSCANF(fp,"%d,%d,%d,%d",	&nx,&ny,&nz,&nl);		NEXT_LINE(fp);
  FSCANF(fp,"%d,%d,%d,%d,%d,%d,%d,%d",&norm_res,&rot_res,
	 &imin,&imax,&jmin,&jmax,&kmin,&kmax);			NEXT_LINE(fp);
                                                                NEXT_LINE(fp);
  FSCANF(fp,"%d",		&show_surface);			NEXT_LINE(fp);
  FSCANF(fp,"%d,"F"",		&ulayer,&uc);			NEXT_LINE(fp);
  FSCANF(fp,"%d,"F","F"",	&vlayer,&vmin,&vmax);		NEXT_LINE(fp);
  FSCANF(fp,"%d,"F","F"",	&wlayer,&wmin,&wmax);		NEXT_LINE(fp);
  FSCANF(fp,"%d,"F","F"",	&color_mode,&alphamin,&alphamax);NEXT_LINE(fp);
                                                                NEXT_LINE(fp);
  FSCANF(fp,"%d",		&show_filament);   		NEXT_LINE(fp);
  FSCANF(fp,"%d,"F"",		&layer1,&const1);		NEXT_LINE(fp);
  FSCANF(fp,"%d,"F"",		&layer2,&const2);		NEXT_LINE(fp);
  FSCANF(fp,""F","F","F","F",%d",&flm_r,&flm_g,&flm_b,&flm_wt,&flm_balls);  NEXT_LINE(fp);
                                                                NEXT_LINE(fp);
  FSCANF(fp,""F","F","F","F,	&theta0,&phi0,&psi0,&distance0);NEXT_LINE(fp);
                                                                NEXT_LINE(fp);
  FSCANF(fp,"%d",		&remove_backs);   		NEXT_LINE(fp);
  FSCANF(fp,"%d",		&clipping);   			NEXT_LINE(fp);
                                                                NEXT_LINE(fp);
  FSCANF(fp,"%d",		&write_images);   		NEXT_LINE(fp);
  FSCANF(fp,"%d",		&write_filament);   		NEXT_LINE(fp);
  FSCANF(fp,"%d,%d,%d,%d",	&write_history,&hist_x,&hist_y,&hist_z); NEXT_LINE(fp);
                                                                NEXT_LINE(fp);
  FSCANF(fp,""F","F","F,	&bg_r,&bg_g,&bg_b);             NEXT_LINE(fp);
  FSCANF(fp,""F","F","F","F","F,&bbox_r,&bbox_g,&bbox_b,&bbox_a,&bbox_wt); NEXT_LINE(fp);
  FSCANF(fp,""F","F"",		&grid_h,&dt);    		NEXT_LINE(fp);
  FSCANF(fp,"%d",		&verbose);			NEXT_LINE(fp); 
#if TRACE 
                                                                NEXT_LINE(fp);
  FSCANF(fp,"%d",		&tracelen);			NEXT_LINE(fp);
  if (tracelen) {
    FGETS(buf,BUFLEN,fp);p=strtok(buf," \t\r\b\n"); sgzfile=strdup(p);
    FSCANF(fp,"%d",		&tracezfix);			NEXT_LINE(fp);
    FSCANF(fp,"%d",		&traceint);			NEXT_LINE(fp);
    FSCANF(fp,F","F","F","F","F","F","F","F,
	   &trl_r,&trl_g,&trl_b,&trl_a,&trl_wt,&trl_dx,&trl_dy,&trl_dz);
                                                                NEXT_LINE(fp);
    /* default values in case the next line is not read */
    trf_r=trl_r; trf_g=trl_g; trf_b=trl_b; trf_a=trl_a; trf_wt=trl_wt;
    FSCANF(fp,F","F","F","F","F","F","F","F,
	   &trf_r,&trf_g,&trf_b,&trf_a,&trf_wt,&trf_dx,&trf_dy,&trf_dz);
                                                                NEXT_LINE(fp);
  } else {
    for(i=0;i<5;i++) NEXT_LINE(fp);
  }
#endif
#if MARKER
                                                                NEXT_LINE(fp);
  FSCANF(fp,F,			&marker_size); 			NEXT_LINE(fp);
  if (marker_size) {
    FSCANF(fp,F","F","F,		&marker_x,&marker_y,&marker_z);	NEXT_LINE(fp);
    FSCANF(fp,""F","F","F","F","F,&marker_r,&marker_g,&marker_b,&marker_a,&marker_wt); NEXT_LINE(fp);
  } else {
    for(i=0;i<2;i++) NEXT_LINE(fp);
  }
#endif
#if TABOO
                                                                NEXT_LINE(fp);
  FSCANF(fp,"%d",		&taboo_byte);			NEXT_LINE(fp);
#endif
#if READFLM
                                                                NEXT_LINE(fp);
  FGETS(buf,BUFLEN,fp); 
  if(*buf) 
    if (NULL!=(p=strtok(buf," \t\r\b\n")))
      flmtemplate=strdup(p);
#endif
  fclose(fp);

#undef FSCANF
#undef FGETS

  if (imax==-1) imax=nx-1;
  if (jmax==-1) jmax=ny-1;
  if (kmax==-1) kmax=nz-1;
  theta=theta0; phi=phi0; psi=psi0; distance=distance0;

  if (verbose>=2) {
    printf("=============================================\n");
    printf("Parameters after reading task:\n");
    #define _(n,t,i) printf(#n"=%g\n",(float)n);
    #include "ezpar.h"
    #undef _
/*     printf("fmt=%s\n",fmt); */
/*     printf("template=%s\n",		template); */
/*     printf("m=%d,%d,%d\n",		mmin,mstep,mmax); */
/*     printf("nx,ny,nz=%d,%d,%d\n",	nx,ny,nz); */
/*     printf("res=%d,%d\n",		norm_res,rot_res); */
/*     printf("initial_field=%d\n",	initial_field); */
/*     printf("u=%d,"F","F","F"\n",		ulayer,umin,umax,uc); */
/*     printf("v=%d,"F","F","F"\n",		vlayer,vmin,vmax,vc); */
/*     printf("colormode,alphamin/max=%d,"F","F"\n",color_mode,alphamin,alphamax); */
/*     printf("theta,phi,psi="F","F","F"\n",theta,phi,psi); */
/*     printf("\n"); */
/*     printf("remove_backs=%d\n",		remove_backs); */
/*     printf("clipping=%d\n",		clipping); */
/*     printf("show_filament=%d\n",	show_filament); */
/*     printf("write_filament=%d\n",	write_filament); */
/*     printf("save_images=%d\n",		save_images); */
/*     printf("write_history=%d\n",	write_history); */
/*     printf("hist x,y,z=%d,%d,%d\n",	hist_x,hist_y,hist_z); */
/*     printf("bg="F","F","F"\n",		bg_r,bg_g,bg_b); */
/*     printf("bbox="F","F","F","F","F"\n",bbox_r,bbox_g,bbox_b,bbox_a,bbox_wt); */
/*     printf("\n"); */
/*     printf("flm="F","F","F","F","F"\n", flm_r,flm_g,flm_b,flm_wt,flm_balls); */
/*     printf("hx,ht="F","F"\n",		grid_h,dt); */
/*     printf("verbose=%d\n",		verbose); */
/* #if TRACE  */
/*     printf("\n"); */
/*     printf("sgzfile=%s\n",		sgzfile); */
/*     printf("tracez=%d\n",		tracez); */
/*     printf("tracelen=%d\n",		tracelen); */
/*     printf("tracelast="F","F","F","F","F"\n",trl_r,trl_g,trl_b,trl_a,trl_wt); */
/*     printf("tracefirst="F","F","F","F","F"\n",trf_r,trf_g,trf_b,trf_a,trf_wt); */
/* #endif */
/* #if MARKER */
/*     printf("\n"); */
/*     printf("marker_size="F"\n", marker_size); */
/*     printf("marker x,y,z="F","F","F"\n",marker_x,marker_y,marker_z); */
/*     printf("marker r,g,b,a,wt="F","F","F","F","F"\n",marker_r,marker_g,marker_b,marker_a,marker_wt); */
/* #endif */
/* #if TABOO */
/*     printf("\n"); */
/*     printf("taboo_byte=%d\n", taboo_byte); */
/* #endif */
    printf("=============================================\n");
  }

  /* ------------ 
   * Final things
   * ------------ */

  Allocate_memory();
  Read_fmt(fmt,template,mmin); 
  if (ulayer>=nl)
    error("ulayer=%d should be less than nl=%d\n",ulayer,nl);
  if (verbose>2) printf("ulayer=%d < nl=%d\n",ulayer,nl);
  if (vlayer>=nl)
    error("vlayer=%d should be less than nl=%d\n",vlayer,nl);
  if (verbose>2) printf("vlayer=%d < nl=%d\n",vlayer,nl);


  if(write_filament) filament_file = fopen("filament.dat", "w"); 
#if TRACE
  if (tracelen) Read_trace(sgzfile,tracezfix);
#endif
  Draw_ini();
  return 1;
}
/* ========================================================================= */

void Allocate_memory (void) {
  /* -----------------------------------------------------------------------
   * There are NX, NY and NZ actual grid points in each direction.
   * field_size = (NX+2)*(NY+2)*(NZ+2) because of the way boundaries are
   * treated.  See ezscroll.h for definition of NX, NY, NZ.
   *                                                                         
   * I try to allocate one big block of memory for everything.
   * Need to think of alternative strategies if this is not enough. 
   * ----------------------------------------------------------------------- */


  field_size = (NZ+2)*(NY+2)*(NX+2);
  fields = (Real *) calloc(nl*field_size, sizeof(Real));

  if (fields == NULL) {
    /* Could not find enough memory.
     * ----------------------------- */
    fprintf(stderr, "\n ****Error: Not enough memory available\n");
    exit(-1);
  }
}
/* ========================================================================= */

void Finish_up (void) {
  QuitX();
  if(write_filament) fclose(filament_file); 
  if(write_history) fclose(history_file);
}
/* ========================================================================= */

/* This routine for outputting the filament data is called from
 * Register_segments() in ezmarching.c where the filament is computed.  */
void Write_filament_point (float x, float y, float z) {

  if (!filament_file) filament_file = fopen("filament.dat", "w");
  if (!filament_file) return;
  if (m<0) return;
  fprintf(filament_file,
	  "%d %.5f %.5f %.5f\n", 
	  m, x, y, z);
  if (verbose>=4) printf(
	  "%d: (%.5f %.5f %.5f)\n", 
	  m, x, y, z);
}
/* ========================================================================= */

/* Mark end of a filament segment ("chain"). */
void Write_filament_segment (void) {

  if (!filament_file) filament_file = fopen("filament.dat", "w");
  if (!filament_file) return;
  fprintf(filament_file,"# end of chain\n\n");
}
/* ========================================================================= */


/* Mark end of a time frame. */
void Write_filament_frame (void) {

  if (!filament_file) filament_file = fopen("filament.dat", "w");
  if (!filament_file) return;
  fprintf(filament_file,"# end of frame\n\n");
}
/* ========================================================================= */

int Read_fmt (char *fmt,char *template,int m) {
  if (0==strcasecmp(fmt,"ez"))   return Read_ez (template,m);
  if (0==strcasecmp(fmt,"tiffsplit")) return Read_tiffsplit (template,m);
  if (0==strcasecmp(fmt,"tiff")) return Read_tiff (template,m);
  if (0==strcasecmp(fmt,"ppm"))  return Read_ppm (template,m);
  if (0==strcasecmp(fmt,"dmp"))  return Read_dmp (template,m,sizeof(Real));
  if (0==strcasecmp(fmt,"dmp,float"))  return Read_dmp (template,m,4);
  if (0==strcasecmp(fmt,"dmp,double"))  return Read_dmp (template,m,8);
  if (0==strcasecmp(fmt,"bbg"))  return Read_bbg (template,m);
  error("Unknown format %s\n", fmt);
}
/* ========================================================================= */

#define U(i,j,k)          Fields(ulayer,i,j,k)
#define V(i,j,k)          Fields(vlayer,i,j,k)
void Write_history (int wrt_step) {
  int l;
  if (!history_file) history_file = fopen("history.dat", "w");
  fprintf(history_file, "%.5f %.5f %.5f\n", dt*(Real)wrt_step, 
	  U(hist_x,hist_y,hist_z), V(hist_x,hist_y,hist_z) ); 

  if(verbose>2) {
    printf("istep = %d; values=", wrt_step);
    for (l=0;l<nlread;l++) {
      if (l) printf(", ");
      printf("%.5f",Fields(l,hist_x,hist_y,hist_z));
    }
    printf("\n");
  }
}
#undef U
#undef V
/* ========================================================================= */

/* The standard EZSCROLL format for ic.dat and fc.dat files */
int Read_ez (char *template,int m) {
  double u_in, v_in;
  Real   *u_tmp, *v_tmp, rx, ry, rz;
  int    nx_ic, ny_ic, nz_ic, npts_ic2, npts_ic3, index, i_tmp, j_tmp, k_tmp, 
         i, j, k;
  char   f_type, dummy;
  FILE  *fp;
  char filename[4096];

  if (nl<2) error("nl=%d is too small for ez format\n",nl);

  sprintf(filename,template,m);
  fp=fopen(filename,"r");
  if (fp==NULL) error("could not open %s\n",filename);

  /* Read nx_ic etc following = sign on second line of file */
  NEXT_LINE(fp);                                     
  while( (dummy=getc(fp)) != '=');                   
  fscanf(fp, "%d, %d, %d", &nx_ic, &ny_ic, &nz_ic);  

  /* Skip to 10th line and read first character to determine type 
     B(inary) or A(scii) */
  for(i=0;i<8;i++) NEXT_LINE(fp); 
  f_type = getc(fp); NEXT_LINE(fp); 
  
  if ( (f_type !='B') && (f_type !='A') ) error("\n ic.dat exists but of unrecognized type Binary or Ascii \n"); 

  if(verbose>=2) printf("\nReading ic.dat with nx, ny, nz = %d, %d, %d... \n", 
		     nx_ic, ny_ic, nz_ic);

  npts_ic2 = nx_ic * ny_ic;  
  npts_ic3 = npts_ic2 * nz_ic;

  /* Allocate temporary memory and read from file */

  u_tmp =(Real *) malloc((unsigned)(npts_ic3)*sizeof(Real));
  v_tmp =(Real *) malloc((unsigned)(npts_ic3)*sizeof(Real));

  if(f_type =='B') {    
    /* Binary data file */
    fread(u_tmp, sizeof(Real), npts_ic3, fp);
    fread(v_tmp, sizeof(Real), npts_ic3, fp);
  }
  else {          
    /* Ascii data file */
    for(index=0;index<npts_ic3;index++) {
      fscanf (fp, "%lg %lg\n", &u_in, &v_in);
      u_tmp[index] = u_in; v_tmp[index] = v_in;
    }
  }

  /* Copy into u and v */
  rx = (nx_ic-1.0)/(NX-1.0);
  ry = (ny_ic-1.0)/(NY-1.0);
  rz = (nz_ic-1.0)/(NZ-1.0);

  for(k=1;k<=NZ;k++) {
    k_tmp = npts_ic2 * (int)(rz*(k-1));
    for(j=1;j<=NY;j++) {
      j_tmp = nx_ic * (int)(ry*(j-1));
      for(i=1;i<=NX;i++) {
	i_tmp = (int)(rx*(i-1));
	Fields(0,i,j,k) = u_tmp[i_tmp + j_tmp + k_tmp];
	Fields(1,i,j,k) = v_tmp[i_tmp + j_tmp + k_tmp];
      }
    }
  }

  free(u_tmp);
  free(v_tmp);  
  return 1;
}
/* ========================================================================= */

/* Series of tiff files, one per each z-section, in one directory */
int Read_tiffsplit (char *template,int m) {
  TIFF *tif;
  char dirname[4096];
  char filename[4096];
  uint32 w,h;
  size_t npixels;
  uint32 *raster;
  unsigned char *bytes;
  Real quant=1.0/255, rx, ry;
  int x,y,z,i,j,l;

  nlread=min(nl,4);
  
  sprintf(dirname,"%s/%%02d.tif",template);
  if (verbose>=2) printf("\nReading %d layers from %s, z=1..%d\n",nlread,dirname,nz);

  raster=NULL;
  for (z=1;z<=nz;z++) {
    sprintf(filename,dirname,m,z-1);
    tif=TIFFOpen(filename,"r");
    if (tif==NULL) {
      fprintf(stderr,"cannot open %s\n",filename); 
      break;
    }
    if (raster==NULL || bytes==NULL) {
      TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &w);
      TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &h);
      npixels = w * h;
      raster = (uint32*) _TIFFmalloc(npixels * sizeof (uint32));
      if (raster==NULL) {
	fprintf(stderr,"not enough memory in Read_tiff_split\b"); 
	break;
      }
      bytes = (unsigned char *)raster;
    }
    if (0==TIFFReadRGBAImage(tif, w, h, raster, 0)) {
      fprintf(stderr,"could not read from %s\n",filename);
      break;
    }
    rx = (w-1.0)/(NX-1.0);
    ry = (h-1.0)/(NY-1.0);
    for (y=1;y<=NY;y++) {
      j = (int)(ry*(y-1));
      for (x=1;x<=NX;x++) {
	i = (int)(rx*(x-1));
	for (l=0;l<nlread;l++) {
	  Fields(l,x,y,z) = quant*bytes[l+4*(i+w*j)];
	}
      }
    }
    TIFFClose(tif);
  }
  _TIFFfree(raster);
  return (z>nz);
}
/* ========================================================================= */

/* Multiple-image tiff file */
int Read_tiff (char *template,int m) {
  TIFF *tif;
  char filename[4096];
  uint32 w,h,d;
  size_t npixels, imagesize;
  uint32 *raster;
  unsigned char *bytes;
  Real quant=1.0/255, rx, ry, rz;
  int x,y,z,i,j,k,l;

  nlread=min(nl,4);
  
  sprintf(filename,template,m);

  if (verbose>=2) printf("\nReading %d layers from %s ...",nlread,filename);

  tif = TIFFOpen(filename, "r");
  if (tif==NULL) error("could not open tiff file %s\n",filename);
  
  /* Assume all images have the same sizes as the first one */
  TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &w);
  TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &h);
  for (d=0;TIFFSetDirectory(tif,d);d++);
  npixels = w * h * d;
  if (verbose>2) printf("file %s data size %d x %d x %d = %ld pixels\n",filename,w,h,d,(long int) npixels);
  imagesize = w * h;
  raster = (uint32*) _TIFFmalloc(npixels * sizeof (uint32));
  if (raster==NULL) error("not enough memory in Read_tiff\n"); 
  bytes = (unsigned char *)raster;
  
  for (k=0;k<d;k++) {
    if (0==TIFFSetDirectory(tif,k)) {
      if (verbose>1) printf("could not find image %d from %s\n",k,filename);
      break;
    }
    if (0==TIFFReadRGBAImage(tif, w, h, raster+k*imagesize, 0)) {
      if (verbose>1) printf("could not read image %d from %s\n",k,filename);
      break;
    }
  }
  TIFFClose(tif);
  if (k<d) {
    if (verbose>1) printf("%d layer required, only %d read from %s; abandoning\n",d,k,filename);
    _TIFFfree(raster); 
    return 0;
  }

  rx = (w-1.0)/(NX-1.0);
  ry = (h-1.0)/(NY-1.0);
  rz = (d-1.0)/(NZ-1.0);
  for (z=1;z<=NZ;z++) {
    k = (int)(rz*(z-1));
    for (y=1;y<=NY;y++) {
      j = (int)(ry*(y-1));
      for (x=1;x<=NX;x++) {
	i = (int)(rx*(x-1));
	for (l=0;l<nlread;l++) {
	  Fields(l,x,y,z) = quant*bytes[l+4*(i+w*(j+k*h))];
	}
      }
    }
  }
  _TIFFfree(raster);
  return 1;
}
/* ========================================================================= */

/* A binary ppm header followed by nz rasters */
/* Will try to read files as gzipped if their names end with 'gz' */
int Read_ppm (char *template,int m) {
  FILE *ppmin;
  char filename[4096], tag[16], newline;
  unsigned char *bytes, thebyte;
  int w, h, d, max;
  Real quant, rx, ry, rz;
  long int firstbyte, lastbyte, nvoxels, npixels, numgood=0;
  int i,j,k,l,x,y,z;
  /* gunzip stuff */
  char *ungzipped=NULL;
  char cmd[4096];
  int rc;

  nlread=min(nl,3);

  /****************************/
  /* Opening the input stream */
  sprintf(filename,template,m);
  if (NULL==strstr(filename,"gz")) {	/* reading straight from the file */
                                                  /* fprintf(stderr,"%s is not a gzipped file\n",filename); */
    ppmin=fopen(filename,"r");
    if (ppmin==NULL) {
      sprintf(cmd,"Read_ppm could not open %s\n",filename);
      perror(cmd);
      return 0;
    }
  } else {				/* reading from gzipped file */
                                                  /* fprintf(stderr,"%s is a gzipped file\n",filename); */
    ungzipped=tempnam(NULL,NULL);
    sprintf(cmd,"gunzip -c %s > %s",filename,ungzipped);
    if (0!=(rc=system(cmd))) {
      fprintf(stderr,"execution of '%s' failed with return code %d:",cmd,rc);
      perror(NULL);
      return 0;
    }
    ppmin=fopen(ungzipped,"r");
    if (ppmin==NULL) {
      fprintf(stderr,"Read_ppm could not open %s:",ungzipped);
      perror(NULL);
      return 0;
    }
  }

  /***********************/
  /* Reading in the data */
  fscanf(ppmin,"%2s ",tag);

  if (0!=strcmp(tag,"P6")) error("%s is not a ppm file\n",filename);
  if (!fscanf(ppmin,"%u ",&w)
   || !fscanf(ppmin,"%u ",&h)
   || !fscanf(ppmin,"%u",&max)
      ) error("could not read dimensions from %s\n",filename);

  quant=1.0/max;
  fscanf(ppmin,"%c",&newline);
  firstbyte=ftell(ppmin);
  fseek(ppmin,0L,SEEK_END);
  lastbyte=ftell(ppmin);
  nvoxels=lastbyte-firstbyte;
  fseek(ppmin,firstbyte,SEEK_SET);
  npixels = 3*w*h;
  if (0!=(nvoxels%npixels)) error("%s nvoxels=%ld not divisible by npixels=%ld\n",filename,nvoxels,npixels);
  d=nvoxels/npixels;

  if(verbose>1) printf("\nReading from %s pixel array %dx%dx%d into visualization array %dx%dx%d\n", 
		       filename,w,h,d,NX,NY,NZ);

  bytes=(unsigned char *)calloc(nvoxels,1);
  if (bytes==NULL) error("not enough memory in Read_ppm\n");
  if (nvoxels != fread(bytes,1,nvoxels,ppmin)) 
    error("error reading from %s\n",filename);

  #define byte(v,i,j,k) bytes[(v)+3*((i)+w*((j)+h*(k)))]

  rx = (w-1.0)/(NX-1.0);
  ry = (h-1.0)/(NY-1.0);
  rz = (d-1.0)/(NZ-1.0);
  for (z=1;z<=NZ;z++) {
    k = (int)(rz*(z-1));
    for (y=1;y<=NY;y++) {
      j = (int)(ry*(y-1));
      for (x=1;x<=NX;x++) {
	i = (int)(rx*(x-1));
	for (l=0;l<nlread;l++) {
	  thebyte=byte(l,i,j,k);
	  Fields(l,x,y,z) = quant*thebyte;
	  numgood+=((int)thebyte!=taboo_byte);
	}
      }
    }
  }
  free(bytes);

  #if TABOO
  taboo = quant*taboo_byte;
  printf("taboo value="F", there are %ld good bytes, %.0f%% fill\n",
	 taboo,numgood,(100.0*numgood)/nvoxels);
  #endif

  /**************/
  /* Closing up */
  if (0!=fclose(ppmin)) perror("Read_ppm cannot close input file");
  if (ungzipped) unlink(ungzipped);

  return 1;
}
/* ========================================================================= */


/* QUI/Beatbox binary dump file.                   */
/* Assume the same data type and raster size       */
/* and deduce number of layers from the file size. */
int Read_dmp (char *template,int m,int intypesize) {
  FILE  *fp;
  char filename[4096];
  long fsize, rc;
  long xmax=NX+2;
  long ymax=NY+2;
  long zmax=NZ+2;
  long vmax; /* CAVEAT: name clash with a global var */
  long inarrsize; 
  char *tmpbuf;
  char *p;
  char typefloat[]="float";
  char typedouble[]="double";
  char *intype;
  int floatsize=4;
  int doublesize=8;
  void *arr;
  Real rx, ry, rz;
  int i,j,k,l,x,y,z;

  /* Sort out the type of input data */
  if (intypesize==floatsize)
    intype=typefloat;
  else if (intypesize==doublesize)
    intype=typedouble;
  else
    error("unknown input type size %d\n",intypesize);

  /* Parse the 'template' which may contain the input array sizes and type */
  tmpbuf=strdup(template);
  if (!(p=strtok(tmpbuf,","))) error("could not find filename in '%s'\n",tmpbuf);
  if (!(sprintf(filename,p,m))) error("could not form filename out of '%s' and m=%d\n",p,m);
  if (!(fp=fopen(filename,"r"))) error("could not open %s\n",filename);
  if (!(p=strtok(NULL,","))) 
    xmax=NX;
  else if (1!=sscanf(p,"%ld",&xmax))
    error("could not interpret '%s' as xmax\n",p);
  if (!(p=strtok(NULL,",")))
    ymax=NY;
  else if (1!=sscanf(p,"%ld",&ymax))
    error("could not interpret '%s' as ymax\n",p);
  if (!(p=strtok(NULL,",")))
    zmax=NZ;
  else if (1!=sscanf(p,"%ld",&zmax))
    error("could not interpret '%s' as zmax\n",p);


  free(tmpbuf);

  /* Measure the input file */
  inarrsize=xmax*ymax*zmax;
  fseek(fp,0,SEEK_END);
  fsize=ftell(fp);
  rewind(fp);
  if (0!=(fsize%(inarrsize*intypesize))) 
    error("%s filesize=%ld not divisible by expected array size=%ld\n",filename,fsize,inarrsize*intypesize);
  vmax=fsize/(inarrsize*intypesize);
  if (verbose>1) printf("%ld layers found in %s\n",vmax,filename);

  nlread=min(vmax,nl);

  assert(fsize=inarrsize*vmax*intypesize);

  /* Allocate the array and read into it */
  if (intypesize==floatsize)
    arr=calloc(xmax*ymax*zmax*vmax,sizeof(float));
  else
    arr=calloc(xmax*ymax*zmax*vmax,sizeof(double));
  if (!arr) error(
    "could not allocate %ldx%ldx%ldx%ld items of type %s\n",
    xmax,ymax,zmax,vmax,intype
  );
  if (intypesize==floatsize)
    rc=fread(arr,sizeof(float),inarrsize*vmax,fp);
  else
    rc=fread(arr,sizeof(double),inarrsize*vmax,fp);
  if (rc!=inarrsize*vmax) error(
    "Warning: %ld instead of %ld items of type %s read from file %s\n",
    rc,inarrsize*vmax,intype,filename
  );
  if (verbose>2) printf(
    "%ld items of type %s read from file %s\n",
    rc,intype,filename
  );


  /* Reshuffle and interpolate if necesary */
  if(verbose>1) printf("\nCopying from input array %ldx%ldx%ldx%ld into two visualization arrays %dx%dx%dx%d\n", 
		       xmax,ymax,zmax,vmax,NX,NY,NZ,nlread);

  /* x=1..NX etc; i=0..xmax-1 etc */
  rx = (xmax-1.0)/(NX-1.0);
  ry = (ymax-1.0)/(NY-1.0);
  rz = (zmax-1.0)/(NZ-1.0);
  for (z=1;z<=NZ;z++) {
    k = (int)(rz*(z-1));
    for (y=1;y<=NY;y++) {
      j = (int)(ry*(y-1));
      for (x=1;x<=NX;x++) {
	i = (int)(rx*(x-1));
        #define iindex(x,y,z,v) ((v)+vmax*((z)+zmax*((y)+ymax*(x))))
	if (intypesize==floatsize) {
	  for (l=0;l<nlread;l++) {
	    Fields(l,x,y,z) = (Real) ((float *)arr)[iindex(i,j,k,l)];
	  }
	} else {
	  for (l=0;l<nlread;l++) {
	    Fields(l,x,y,z) = (Real) ((double *)arr)[iindex(i,j,k,l)];
	  }
	}
	#undef iindex
      }
    }
  }
  free(arr);

  return 1;
}
/* ========================================================================= */

/* The Beatbox's "bbg" format */
int Read_bbg (char *template,int m) {
  FILE  *fp;
  char filename[4096];
  int x, y, z, l, xmin, xmax, ymin, ymax, zmin, zmax, NF, status;
  Real in[4];

  nlread=min(4,nl);
  #define GEOM_VOID   0

  
  sprintf(filename,template,m);
  fp=fopen(filename,"r");
  if (fp==NULL) error("could not open %s\n",filename);

  xmin=NX+1; xmax=-1;
  ymin=NY+1; ymax=-1;
  zmin=NZ+1; zmax=-1;

  while ((NF=fscanf(fp, 
		"%d,%d,%d,%d,"F","F","F"\n",
		    &x, &y, &z, &status, &(in[1]), &(in[2]), &(in[3])))
	 != EOF) {
    if (NF<4) continue;
    if (status==GEOM_VOID) continue;
    if (x>xmax) xmax=x; if (x<xmin) xmin=x;
    if (y>ymax) ymax=y; if (y<ymin) ymin=y;
    if (z>zmax) zmax=z; if (z<zmin) zmin=z;
    if (x<0 || x>=NX) continue;
    if (y<0 || y>=NY) continue;
    if (z<0 || z>=NZ) continue;

    in[0]=status;
    if (NF<7) in[1]=in[2]=in[3]=0;
    for (l=0;l<nlread;l++) {
      Fields(l,x,y,z) = in[l];
    }
  }
  if (verbose) printf("%s: x=[%d:%d] y=[%d:%d] z=[%d:%d] boxsize=(%d,%d,%d,%d)\n",
		      filename,xmin,xmax,ymin,ymax,zmin,zmax,NX,NY,NZ,nlread);

  return 1;
  #undef GEOM_VOID
}
/* ========================================================================= */


#if TRACE
long ntrace;
long *tracet;
Real *tracex;
Real *tracey;
Real *tracez;
long Read_trace (char *filename, int tracezfix) {
  long int n, t;
  float x,y,z;
  #define BUFLEN 4096
  char buf[BUFLEN];
  FILE *fp=fopen(filename,"r");
  ntrace=0; /* presume failure to simplify error exist */
  if (NULL==fp) 
    error("could not open trace file %s for reading; assume no records\n",filename);

  /* dry run to find out size of the arrays */
  n=0;
  while (!feof(fp)) {
    fgets(buf,BUFLEN,fp);
    if (0==strlen(buf)) continue;
    if (4!=sscanf(buf,"%ld %g %g %g",&t,&x,&y,&z)) continue;
    if (tracezfix>=0 && z!=tracezfix) continue;
    n++;
  }
#define CALLOC(a,t) \
  if (NULL==(a=(t *)calloc(n,sizeof(t)))) \
    error("not enough memory for " #a "\n");
  CALLOC(tracet,long);
  CALLOC(tracex,Real);
  CALLOC(tracey,Real);
  CALLOC(tracez,Real);
#undef CALLOC
  ntrace=n;

  /* all over again, this time filling in the arrays */
  rewind(fp);
  n=0;
  while (!feof(fp)) {
    fgets(buf,BUFLEN,fp);
    if (0==strlen(buf)) continue;
    if (4!=sscanf(buf,"%ld %g %g %g",&t,&x,&y,&z)) continue;
    if (tracezfix>=0 && z!=tracezfix) continue;
    tracet[n]=t;
    tracex[n]=x;
    tracey[n]=y;
    tracez[n]=z;
    n++;
  }
  return ntrace;
}
#endif


void play (char *soundfilename) {
  char cmd[128];
  sprintf(cmd,"afplay /System/Library/Sounds/%s.aiff",soundfilename);
  system(cmd);
}
